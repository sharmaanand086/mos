<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Event extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('event_model');
        $this->isLoggedIn();   
    }
    
 /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'HJM : Dashboard';
        
        $this->loadViews("admin/dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the slider list
     */
     
   function eventListing(){    
      
     // if($this->isAdmin() == TRUE)
     //    {
     //        $this->loadThis();
     //    }
     //    else
     //    {   
         $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->event_model->eventListingCount($searchText);

            $returns = $this->paginationCompress ( "eventListing/", $count, 10 );
           
            $data['eventRecords'] = $this->event_model->eventListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'HJM : Event Listing';
            
            $this->loadViews("admin/event", $this->global, $data, NULL); 
        // }
   }
    /**
     * This function is used to load the add new form
     */
    function addEvent()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $this->load->model('event_model');           
            
            $this->global['pageTitle'] = 'HJM : Add Event';

            $this->loadViews("admin/addEvents", $this->global,NULL, NULL);
        //}
    }


      /**
     * This function is used to add new user to the system
     */
    function InsertEvent(){
         $data['name'] = $this->input->post('name',true);

         if(!empty($data['name']) ){

            if(isset($_FILES['sliderimage']) && is_uploaded_file($_FILES['sliderimage']['tmp_name']))
                {
                 $path =  realpath(APPPATH.'../assets/event/images');
                  $config['upload_path']=$path;
                  $config['max_size']=20000;
                  $config['allowed_types']='gif|png|jpeg|jpg';
                   
                  $this->load->library('upload',$config);
                  if(!$this->upload->do_upload('sliderimage')){
                    $error = $this->upload->display_errors();
                    //var_dump($error);
                    setFlashData1('alert-danger',$error,'addEvent');
                  }else{
                    $fileName = $this->upload->data();
                    //var_dump($fileName);f
                    $data['imagename'] = $fileName['file_name'];
                     
                     $times= date("Y-m-d H:i:s");
                     $data['createdDtm']= $times;                  
                     
                  }
                }
                 $res1 = $this->event_model->checkevent($data);

                 if($res1 > 0){
                  setFlashData1('btn-danger','Event Already Exists','addEvent');
                   }else{
                    $data['roleId']= $this->session->userdata ( 'role' );
                    $data['userId']= $this->session->userdata ( 'userId' );
                    $data['isDeleted']=0;
                    $data['createdBy']=$this->session->userdata ( 'userId' );

                   $res = $this->event_model->addnewEvent($data);
                 if($res >0){
                          setFlashData1('btn-success','You have successfully added','addEvent');
                    }else{
                     setFlashData1('btn-danger','You can not add now','addEvent');
                   }
                 } 
            }else{
            setFlashData1('btn-danger','all The Fields is Required','addEvent');
       }



}

 function viewImage($id = NULL)
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $id = ($id == NULL ? 0 : $id);  
            $data['usereventRecords'] = $this->event_model->getImage($id);
            
            $this->global['pageTitle'] = 'HJM : Image History';
            
            $this->loadViews("admin/viewEvent_Image", $this->global, $data, NULL);
       // }        
    }

    
    function approveEvent()
    {
       if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $eventid = $this->input->post('eventid');
            $status = array('status'=>'1');
            
            $result = $this->event_model->approveImage($eventid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

 function rejectEvent()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $eventid = $this->input->post('eventid');
            $status = array('status'=>'2');
            
            $result = $this->event_model->RejectImage($eventid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    function deleteEvent()
    {
        //  if($this->isAdmin() == TRUE)
        // {
        //     echo(json_encode(array('status'=>'access')));
        // }
        // else
        // {
             $eventid = $this->input->post('eventid');
            $statusdel = array('isDeleted'=>1);
            
            $result = $this->event_model->deleteNews($eventid, $statusdel);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        //}
    }
    
}