<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Download extends CI_Controller {

	public function index(){
		$this->load->library('pagination');
		$config["base_url"] = base_url() . "download/index";
		$config['total_rows'] = 22;
		$config['per_page'] = 10;
		$config["uri_segment"] = 3;

		$config["next_link"] = "Next";
		$config["next_tag_open"] = '<li> ';
		$config["next_tag_close"] = ' </li>';

		$config["prev_link"] = "Prev";
		$config["prev_tag_open"] = '<li> ';
		$config["prev_tag_close"] = '</li>';

		$config['num_tag_open'] = '<li>'; 
		$config['num_tag_close'] = '</li>'; 
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">'; 
		$config['cur_tag_close'] = '</a></li>'; 

		$this->pagination->initialize($config);
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['pray'] = $this->getpray();
        $data["links"] = $this->pagination->create_links();

        $data['authors'] = $this->commonmodel->getdownload($config["per_page"], $page);

		$this->load->view('download', $data);

	}
	public function getpray(){
		$currentdate = explode('-', date('F-d'));
		$data = $this->commonmodel->get_today_pray($currentdate[0],$currentdate[1]);
		return $data;
	}
}