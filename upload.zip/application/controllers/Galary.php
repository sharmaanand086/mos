<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Galary extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('galary_model');
        $this->isLoggedIn();   
    }
    
 /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'HJM : Dashboard';
        
        $this->loadViews("admin/dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the slider list
     */
     
   function galaryListing(){
     // if($this->isAdmin() == TRUE)
     //    {
     //        $this->loadThis();
     //    }
     //    else
     //    {   
         $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->galary_model->GalaryListingCount($searchText);

            $returns = $this->paginationCompress ( "galaryListing/", $count, 10 );
            
            $data['galaryRecords'] = $this->galary_model->GalaryListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'HJM : galary Listing';
            
            $this->loadViews("admin/galary", $this->global, $data, NULL); 
       // }
   }
    /**
     * This function is used to load the add new form
     */
    function addGalary()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $this->load->model('galary_model');           
            
            $this->global['pageTitle'] = 'HJM : Add Galary';

            $this->loadViews("admin/addGalary", $this->global,NULL, NULL);
        //}
    }


      /**
     * This function is used to add new user to the system
     */
    function InsertGalary(){
         $data['name'] = $this->input->post('name',true);

         if(!empty($data['name']) ){

            if(isset($_FILES['sliderimage']) && is_uploaded_file($_FILES['sliderimage']['tmp_name']))
                {
                 $path =  realpath(APPPATH.'../assets/galary/images');
                  $config['upload_path']=$path;
                  $config['max_size']=20000;
                  $config['allowed_types']='gif|png|jpeg|jpg';
                   
                  $this->load->library('upload',$config);
                  if(!$this->upload->do_upload('sliderimage')){
                    $error = $this->upload->display_errors();
                    //var_dump($error);
                    setFlashData1('alert-danger',$error,'addGalary');
                  }else{
                    $fileName = $this->upload->data();
                    //var_dump($fileName);f
                    $data['imagename'] = $fileName['file_name'];
                     
                     $times= date("Y-m-d H:i:s");
                     $data['createdDtm']= $times;                  
                     
                  }
                }
                 $res1 = $this->galary_model->checkgalary($data);

                 if($res1 > 0){
                  setFlashData1('btn-danger','Galary Already Exists','addGalary');
                   }else{
                    $data['roleId']= $this->session->userdata ( 'role' );
                    $data['userId']= $this->session->userdata ( 'userId' );
                    $data['isDeleted']=0;
                    $data['createdBy']=$this->session->userdata ( 'userId' );

                   $res = $this->galary_model->addnewGalary($data);
                 if($res >0){
                          setFlashData1('btn-success','You have successfully added','addGalary');
                    }else{
                     setFlashData1('btn-danger','You can not add now','addGalary');
                   }
                 } 
            }else{
            setFlashData1('btn-danger','all The Fields is Required','addGalary');
       }



}

 function viewImage($id = NULL)
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $id = ($id == NULL ? 0 : $id);  
            $data['usergalaryRecords'] = $this->galary_model->getImage($id);
            
            $this->global['pageTitle'] = 'HJM : Image History';
            
            $this->loadViews("admin/viewgalary_Image", $this->global, $data, NULL);
        //}        
    }

    
    function approveGalary()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $galaryid = $this->input->post('galaryid');
            $status = array('status'=>'1');
            
            $result = $this->galary_model->approveImage($galaryid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

 function rejectGalary()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $galaryid = $this->input->post('galaryid');
            $status = array('status'=>'2');
            
            $result = $this->galary_model->RejectImage($galaryid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    function deleteGalary()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     echo(json_encode(array('status'=>'access')));
        // }
        // else
        // {
             $galaryid = $this->input->post('galaryid');
            $statusdel = array('isDeleted'=>1);
            
            $result = $this->galary_model->deleteNews($galaryid, $statusdel);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
       // }
    }
    
}