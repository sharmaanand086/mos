<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class News extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('news_model');
        $this->isLoggedIn();   
    }
    
 /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'HJM : Dashboard';
        
        $this->loadViews("admin/dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the slider list
     */
     
   function newsListing(){
     // if($this->isAdmin() == TRUE)
     //    {
     //        $this->loadThis();
     //    }
     //    else
     //    {   
         $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->news_model->newsListingCount($searchText);

            $returns = $this->paginationCompress ( "newsListing/", $count, 10 );
            
            $data['newsRecords'] = $this->news_model->newsListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'HJM : News Listing';
            
            $this->loadViews("admin/news", $this->global, $data, NULL); 
        //}
   }
    /**
     * This function is used to load the add new form
     */
    function addNews()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $this->load->model('news_model');           
            
            $this->global['pageTitle'] = 'HJM : Add News';

            $this->loadViews("admin/addNews", $this->global,NULL, NULL);
        //}
    }


      /**
     * This function is used to add new user to the system
     */
    function InsertNews(){
         $data['name'] = $this->input->post('name',true);

         if(!empty($data['name']) ){

            if(isset($_FILES['sliderimage']) && is_uploaded_file($_FILES['sliderimage']['tmp_name']))
                {
                 $path =  realpath(APPPATH.'../assets/news/images');
                  $config['upload_path']=$path;
                  $config['max_size']=20000;
                  $config['allowed_types']='gif|png|jpeg|jpg';
                   
                  $this->load->library('upload',$config);
                  if(!$this->upload->do_upload('sliderimage')){
                    $error = $this->upload->display_errors();
                    //var_dump($error);
                    setFlashData1('alert-danger',$error,'addNews');
                  }else{
                    $fileName = $this->upload->data();
                    //var_dump($fileName);f
                    $data['imagename'] = $fileName['file_name'];
                     
                     $times= date("Y-m-d H:i:s");
                     $data['createdDtm']= $times;                  
                     
                  }
                }
                 $res1 = $this->news_model->checkNews($data);

                 if($res1 > 0){
                  setFlashData1('btn-danger','News Already Exists','addNews');
                   }else{
                    $data['roleId']= $this->session->userdata ( 'role' );
                    $data['userId']= $this->session->userdata ( 'userId' );
                    $data['isDeleted']=0;
                    $data['createdBy']=$this->session->userdata ( 'userId' );

                   $res = $this->news_model->addnewNews($data);
                 if($res >0){
                          setFlashData1('btn-success','You have successfully added','addNews');
                    }else{
                     setFlashData1('btn-danger','You can not add now','addNews');
                   }
                 } 
            }else{
            setFlashData1('btn-danger','all The Fields is Required','addNews');
       }



}

 function viewImage($id = NULL)
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $id = ($id == NULL ? 0 : $id);  
            $data['usernewsRecords'] = $this->news_model->getImage($id);
            
            $this->global['pageTitle'] = 'HJM : Image History';
            
            $this->loadViews("admin/viewnews_Image", $this->global, $data, NULL);
        //}        
    }

    
    function approveNews()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $Newsid = $this->input->post('Newsid');
            $status = array('status'=>'1');
            
            $result = $this->news_model->approveImage($Newsid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

 function rejectNews()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $Newsid = $this->input->post('Newsid');
            $status = array('status'=>'2');
            
            $result = $this->news_model->RejectImage($Newsid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    function deleteNews()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     echo(json_encode(array('status'=>'access')));
        // }
        // else
        // {
             $Newsid = $this->input->post('Newsid');
            $statusdel = array('isDeleted'=>1);
            
            $result = $this->news_model->deleteNews($Newsid, $statusdel);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
       // }
    }
    
}