<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Slider extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('slider_model');
        $this->isLoggedIn();   
    }
    
 /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'HJM : Dashboard';
        
        $this->loadViews("admin/dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the slider list
     */
     
   function sliderListing(){
     // if($this->isAdmin() == TRUE)
     //    {
     //        $this->loadThis();
     //    }
     //    else
     //    {   
         $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->slider_model->sliderListingCount($searchText);

            $returns = $this->paginationCompress ( "sliderListing/", $count, 10 );
            
            $data['sliderRecords'] = $this->slider_model->sliderListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'HJM : Slider Listing';
            
            $this->loadViews("admin/slider", $this->global, $data, NULL); 
        //}
   }
    /**
     * This function is used to load the add new form
     */
    function addNewslider()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $this->load->model('slider_model');           
            
            $this->global['pageTitle'] = 'HJM : Add New Slider';

            $this->loadViews("admin/addNewslider", $this->global,NULL, NULL);
        //}
    }


      /**
     * This function is used to add new user to the system
     */
    function InsertNewslider(){
         $data['name'] = $this->input->post('name',true);

         if(!empty($data['name']) ){

            if(isset($_FILES['sliderimage']) && is_uploaded_file($_FILES['sliderimage']['tmp_name']))
                {
                 $path =  realpath(APPPATH.'../assets/slider/images');
                  $config['upload_path']=$path;
                  $config['max_size']=20000;
                  $config['allowed_types']='gif|png|jpeg|jpg';
                   
                  $this->load->library('upload',$config);
                  if(!$this->upload->do_upload('sliderimage')){
                    $error = $this->upload->display_errors();
                    //var_dump($error);
                    setFlashData1('alert-danger',$error,'addNewslider');
                  }else{
                    $fileName = $this->upload->data();
                    //var_dump($fileName);f
                    $data['imagename'] = $fileName['file_name'];
                     
                     $times= date("Y-m-d H:i:s");
                     $data['createdDtm']= $times;                  
                     
                  }
                }
                 $res1 = $this->slider_model->checkslider($data);

                 if($res1 > 0){
                  setFlashData1('btn-danger','slider Already Exists','addNewslider');
                   }else{
                    $data['roleId']= $this->session->userdata ( 'role' );
                    $data['userId']= $this->session->userdata ( 'userId' );
                    $data['isDeleted']=0;
                    $data['createdBy']=$this->session->userdata ( 'userId' );

                   $res = $this->slider_model->addnewslider($data);
                 if($res >0){
                          setFlashData1('btn-success','You have successfully added','addNewslider');
                    }else{
                     setFlashData1('btn-danger','You can not add now','addNewslider');
                   }
                 } 
            }else{
            setFlashData1('btn-danger','all The Fields is Required','addNewslider');
       }



}

 function viewImage($id = NULL)
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     $this->loadThis();
        // }
        // else
        // {
            $id = ($id == NULL ? 0 : $id);  
            $data['usersliderRecords'] = $this->slider_model->getImage($id);
            
            $this->global['pageTitle'] = 'HJM : Image History';
            
            $this->loadViews("admin/viewImage", $this->global, $data, NULL);
       // }        
    }

    
    function approveUser()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $sliderid = $this->input->post('sliderid');
            $status = array('status'=>'1');
            
            $result = $this->slider_model->approveImage($sliderid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
       }
    }

 function rejectslider()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $sliderid = $this->input->post('sliderid');
            $status = array('status'=>'2');
            
            $result = $this->slider_model->RejectImage($sliderid, $status);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    function deleteslider()
    {
        // if($this->isAdmin() == TRUE)
        // {
        //     echo(json_encode(array('status'=>'access')));
        // }
        // else
        // {
             $sliderid = $this->input->post('sliderid');
            $statusdel = array('isDeleted'=>1);
            
            $result = $this->slider_model->deleteslider($sliderid, $statusdel);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
       // }
    }
    
}