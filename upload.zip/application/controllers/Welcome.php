<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once(APPPATH."third_party/phpmailer/class.phpmailer.php");

class Welcome extends CI_Controller {
	
	public function index()
	{
		$currentdate = explode('-', date('F-d'));
		$data['pray'] = $this->commonmodel->get_today_pray($currentdate[0],$currentdate[1]);
		$data['news'] = $this->commonmodel->get_news();
		$data['events'] = $this->commonmodel->get_event();
		$this->load->view('index',$data);
	}
	public function show_news($id,$title){
		$data['pray'] = $this->getpray();
		$data['news'] = $this->commonmodel->get_particular_news($id);
		$this->load->view('shownews',$data);
	}
	public function show_event($id,$title){
		$data['pray'] = $this->getpray();
		$data['events'] = $this->commonmodel->get_particular_events($id);
		$this->load->view('showevent',$data);
	}
	public function menu($filename)
	{
		$data['pray'] = $this->getpray();
		$this->load->view($filename,$data);
	}
	public function services(){
		$data['pray'] = $this->getpray();
		$this->load->view('services',$data);
	}
	// Gallery phoyo
	public function photo($id){
		$data['pray'] = $this->getpray();
		$data['photo'] = $this->commonmodel->get_photo_gallery($id);
		$this->load->view('photo',$data);
	}

	// Children class
	public function ceducation($id){
		$data['pray'] = $this->getpray();
		$data['education'] = $this->commonmodel->get_photo_gallery($id);
		$this->load->view('ceducation',$data);
	}

	//about us
	public function menu1($filename)
	{
		$data['pray'] = $this->getpray();
		$this->load->view($filename,$data);
	}
	public function aboutus(){
		$data['pray'] = $this->getpray();
		$this->load->view('about-us',$data);
	}
	public function education($filename){
		$data['pray'] = $this->getpray();
		$this->load->view($filename,$data);
	}
	public function allnews(){
		$data['pray'] = $this->getpray();
		$data['newes'] = $this->commonmodel->get_all_news();
		$this->load->view('allnews',$data);
	}
	public function allevent(){
		$data['pray'] = $this->getpray();
		$data['events'] = $this->commonmodel->get_all_event();
		$this->load->view('allevent',$data);
	}

	public function getpray(){
		$currentdate = explode('-', date('F-d'));
		$data = $this->commonmodel->get_today_pray($currentdate[0],$currentdate[1]);
		return $data;
	}

	public function media($filename){
		$data['pray'] = $this->getpray();
		$this->load->view($filename,$data);
	}

	public function userfullink(){
		$data['pray'] = $this->getpray();
		$this->load->view('useful-links',$data);
	}

	//contact us
	public function contactus(){
		$this->load->view('contact');
	}
	
	//The dawah Project
	public function thedawahproject(){
		$this->load->view('thedawahproject');
	}
	
	//The dawah Project
	public function talkdata(){
		$this->load->view('talkdata');
	}
	public function islamic(){
	    $data['pray'] = $this->getpray();
		$this->load->view('islamic',$data);
	}
	
	//Talk Imam code
	public function submitimam(){
	    $name = $this->input->post('first',true);
              $emailid = $this->input->post('email',true);
              $phonenumber = $this->input->post('give_last',true);
              $problem = $this->input->post('give_last1',true);
              
              $data = array(
                'name' => $name,
                'email' => $emailid,
                'phone' => $phonenumber,
                'problem'=> $problem
        		);
		$a = $this->commonmodel->talkdata($data);
	    
	    $mail = new PHPMailer(true); // the true param means it will throw exceptions on     errors, which we need to catch
      $mail->IsSMTP(); // telling the class to use SMTP
	$mail->Host = 'mail.hashthattags.com';  // Specify main and backup server
	$mail->Port = '587';
	$mail->SMTPAuth = 'true';                               // Enable SMTP authentication
	$mail->Username = 'support@hashthattags.com';                            // SMTP username
	$mail->Password = 'Barricade@123';
      try 
      {
        $mail->SetFrom('support@hashthattags.com', 'Hashthattags');
        $mail->AddAddress('bhaveshgurav515@gmail.com', '');
        $mail->Subject = 'Test';
        $mail->Body= '<html><body>
        Name : '.$name.'<br>
        Email : '.$emailid.'<br>
        phone : '.$phonenumber.'<br>
        Problem : '.$problem.'
        </body>
        </html>';
            $mail->IsHTML(true);
            $mail->Send();
            echo "asdsadas";
          } 
          catch (phpmailerException $e) 
          {
            echo $e->errorMessage(); //Pretty error messages from PHPMailer
          } 
          catch (Exception $e) 
          {
            echo $e->getMessage(); //Boring error messages from anything else!
          }
          redirect('welcome/thankyou');
	}
	
	//Talk Imam code
	public function submitislam(){
	    $name = $this->input->post('first',true);
              $emailid = $this->input->post('email',true);
              $phonenumber = $this->input->post('give_last',true);
              $problem = $this->input->post('give_last1',true);
              
              $data = array(
                'name' => $name,
                'email' => $emailid,
                'phone' => $phonenumber,
                'problem'=> $problem
        		);
		$a = $this->commonmodel->talkdata($data);
	    
	    $mail = new PHPMailer(true); // the true param means it will throw exceptions on     errors, which we need to catch
      $mail->IsSMTP(); // telling the class to use SMTP
	$mail->Host = 'mail.hashthattags.com';  // Specify main and backup server
	$mail->Port = '587';
	$mail->SMTPAuth = 'true';                               // Enable SMTP authentication
	$mail->Username = 'support@hashthattags.com';                            // SMTP username
	$mail->Password = 'Barricade@123';
      try 
      {
        $mail->SetFrom('support@hashthattags.com', 'Hashthattags');
        $mail->AddAddress('bhaveshgurav515@gmail.com', '');
        $mail->Subject = 'Test';
        $mail->Body= '<html><body>
        Name : '.$name.'<br>
        Email : '.$emailid.'<br>
        phone : '.$phonenumber.'<br>
        Problem : '.$problem.'
        </body>
        </html>';
            $mail->IsHTML(true);
            $mail->Send();
            echo "asdsadas";
          } 
          catch (phpmailerException $e) 
          {
            echo $e->errorMessage(); //Pretty error messages from PHPMailer
          } 
          catch (Exception $e) 
          {
            echo $e->getMessage(); //Boring error messages from anything else!
          }
          redirect('welcome/thankyou');
	}
	
	public  function subscribe(){
		$data = array(
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone']
		);
		$a = $this->commonmodel->subcc($data);
		echo $a;
	}
	public function form(){
		$error_message = '';
		if(empty($_POST['name'])){ /* Name */
			echo "Fields are not filled properly";
			die();
		}else if(empty($_POST['email'])){ /* Email */
			echo "Fields are not filled properly";
			die();
			}else if(empty($_POST['subject'])){ /* Subject */
			echo "Fields are not filled properly";
			die();
		}else if(empty($_POST['message'])){ /* Comment Message */
			echo "Fields are not filled properly";
			die();
		}else{     
		$data = array(
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'subject' => $_POST['subject'],
        'message' => $_POST['message']
		);
		$a = $this->commonmodel->contactus($data);
			if($a == 1){
				redirect('thankyou');
			}else{
				echo "Somthing went wrong!!";
				die();
			}
		}
	}
	public function thankyou(){
		$this->load->view('thankyou');
	}
	public function thankyoupayment(){
		$this->load->view('thankyoupayment');
	}
	public function failedpayment(){
		$this->load->view('failedpayment');
	}
	public function booking(){
		$this->load->view('booking');
	}
	public function donation(){
		$this->load->view('donation');
	}
	public function prayertimetable($month){
		$currentdate = explode('-', date('F-d'));
		$data['currentd'] = $currentdate[1];
		$data['curentm'] = $currentdate[0];
		$data['urlvalue'] = $month;
		$data['month'] = $this->commonmodel->getallmonth();
		$data['data'] = $this->commonmodel->getalldata($month);
		$this->load->view('prayertimetable',$data);
	}

	//Donation
	public function donationpayment(){
		$data = array(
        'name' => $_POST['first'],
        'email' => $_POST['email'],
        'phone' => $_POST['give_last'],
        'amount' => $_POST['give-radio-donation-level'],
        'status' => 0,
        'oder_id' => '',
        'fund'=>$_POST['fund'],
        'modepayment'=>$_POST['paymod']
		);
		$a = $this->commonmodel->donationdata($data);
		//var_dump($_POST['paymod']);
		if($_POST['paymod'] == "stripe"){
		   redirect('welcome/donationcard/'.$a.'/donation'); 
		}
		if($_POST['paymod'] == "Paypal"){
    		    redirect('paypal?id='.$a.'&data=donation');
		}
	}
	public function donationcard($a,$b){
		if($b == 'donation'){
			$data['alldata'] = $this->commonmodel->paydonation($a);
			$data['id'] = $a;
		}
		$this->load->view('viewcard',$data);
	}
	public function getpayment(){

		$payment_id = $statusMsg = ''; 
		$ordStatus = 'error'; 
		if(!empty($_POST['stripeToken'])){ 
		    $token  = $_POST['stripeToken']; 
		    $name = $_POST['name']; 
		    $email = $_POST['email']; 
		    $itemName = 'Donation';
		    $itemPrice = $_POST['price']; 
		    $id=$_POST['id'];
		    $currency = 'gbp';
		    // Include Stripe PHP library 
		    require_once(APPPATH.'libraries/stripe/init.php');
		    // Set API key 
		    \Stripe\Stripe::setApiKey('sk_test_51Coyv6Fiveg2tuPoleiqJ1mWqxhQfQgzhi62oikv4M0NltmFfg4N9LxHNzIAInwaTQQSBWu7WdxHQnb8l584SKAz00Vbf9sfCZ'); 
    // Add customer to stripe 
    try {  
        $customer = \Stripe\Customer::create(array( 
            'email' => $email, 
            'source'  => $token 
        )); 
    }catch(Exception $e) {  
        $api_error = $e->getMessage();  
    } 
    if(empty($api_error) && $customer){  
        // Convert price to cents 
        $itemPriceCents = ($itemPrice*100); 
        // Charge a credit or a debit card 
        try {  
            $charge = \Stripe\Charge::create(array( 
                'customer' => $customer->id, 
                'amount' => $itemPriceCents,
                'currency' => $currency,
                'description' => $itemName 
            )); 
        }catch(Exception $e) {  
            $api_error = $e->getMessage();  
        } 
        if(empty($api_error) && $charge){ 
            // Retrieve charge details 

            $chargeJson = $charge->jsonSerialize(); 
            // Check whether the charge is successful 
            if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){ 

                // Transaction details  

                $transactionID = $chargeJson['balance_transaction']; 

                $paidAmount = $chargeJson['amount']; 

                $paidAmount = ($paidAmount/100); 

                $paidCurrency = $chargeJson['currency']; 

                $payment_status = $chargeJson['status']; 
                $payment_id = rand(10,1000);

                // If the order is successful
                if($payment_status == 'succeeded'){ 
                    $ordStatus = 'success'; 
                    $statusMsg = 'Your Payment has been Successful!'; 
                    $this->commonmodel->updatetoken($id,$transactionID);
                    redirect('thankyoupayment');
				                }else{ 
				                    $statusMsg = "Your Payment has Failed!"; 
				                } 

				            }else{ 
				                $statusMsg = "Transaction has been failed!"; 
				            } 

				        }else{ 
				            $statusMsg = "Charge creation failed! $api_error";  
				        } 
				    }else{  
				        $statusMsg = "Invalid card details! $api_error";  
				    } 
				}else{ 
				    $statusMsg = "Error on form submission."; 
				} 
				
	}


	//all Form
	//booking
	public function bookingform(){
		$data = array(
        'name' => $_POST['fnameh'],
        'email' => $_POST['email'],
        'phone' => $_POST['phoneh'],
        'address' => $_POST['addressh'],
        'onbehalf' => $_POST['onbehalf'],
        'dojectevent' => $_POST['objectevent'],
        'attadult' => $_POST['appadult'],
        'attchild' => $_POST['appchildren'],
        'food' => $_POST['foodserv'],
        'dua' => $_POST['hukr'],
        'hjm' => $_POST['purpose'],
        'place' => $_POST['placeh'],
        'time' => $_POST['timeh'],
        'days' => $_POST['daysh'],
        'dates' => $_POST['datesh'],
        'deposite' => $_POST['damount'],
        'hall' => $_POST['bookingprice'],
        'tran_id' => '',
        'paymode' => $_POST['paymode']

		);
		$a = $this->commonmodel->setbookingform($data);
		if($_POST['paymode'] == 'stripe'){
		redirect('welcome/getstripecard/'.$a.'/booking');
		}
        if($_POST['paymode'] == 'Paypal'){
		    redirect('paypal?id='.$a.'&data=&booking');
		}
	} 
	//marriage
	public function nikahform(){

		$config['upload_path'] = './upload/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = 5000;
        $config['encrypt_name'] = true;
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('profaddbri')) {
            $error = array('error' => $this->upload->display_errors());
           // redirect('services/marriage');
        } else {
            $profaddbri =  $this->upload->data();
           $profaddbriimage = $profaddbri['file_name'];
        }
        if (!$this->upload->do_upload('profaddbgrom')) {
            $error = array('error' => $this->upload->display_errors());
            //redirect('services/marriage');
        } else {
            $profaddbgrom =  $this->upload->data();
           $profaddbgromimage = $profaddbgrom['file_name'];
        }
        if (!$this->upload->do_upload('brideid')) {
            $error = array('error' => $this->upload->display_errors());
            //redirect('services/marriage');
        } else {
            $brideid =  $this->upload->data();
           $brideidimage = $brideid['file_name'];
        }
        if (!$this->upload->do_upload('bridegroomid')) {
            $error = array('error' => $this->upload->display_errors());
           // redirect('services/marriage');
        } else {
            $bridegroomid =  $this->upload->data();
           $bridegroomidimage = $bridegroomid['file_name'];
        }
        if (!$this->upload->do_upload('passphotdr')) {
            $error = array('error' => $this->upload->display_errors());
           // redirect('services/marriage');
        } else {
            $passphotdr =  $this->upload->data();
           $passphotdrimage = $passphotdr['file_name'];
        }
        if (!$this->upload->do_upload('meecertifi')) {
            $error = array('error' => $this->upload->display_errors());
           // redirect('services/marriage');
        } else {
            $meecertifi =  $this->upload->data();
           $meecertifiimage = $meecertifi['file_name'];
        }
        if (!$this->upload->do_upload('previosmarr')) {
            $error = array('error' => $this->upload->display_errors());
           // redirect('services/marriage');
        } else {
            $previosmarr =  $this->upload->data();
           $previosmarrimage = $previosmarr['file_name'];
        }
        if (!$this->upload->do_upload('deathcerti')) {
            $error = array('error' => $this->upload->display_errors());
            //redirect('services/marriage');
        } else {
            $deathcerti =  $this->upload->data();
           $deathcertiimage = $deathcerti['file_name'];
        }
        if (!$this->upload->do_upload('muslimconver')) {
            $error = array('error' => $this->upload->display_errors());
            //redirect('services/marriage');
        } else {
            $muslimconver =  $this->upload->data();
           $muslimconverimage = $muslimconver['file_name'];
        }
        
        if($_POST['madd'] == "masjid"){
            $amount = 100;
        }else{
            $amount = 150;
        }
        $data = array(
        'nikahdate' => $_POST['nikahdate'],
        'nikahtime' => $_POST['nikahtime'],
        'madd' => $_POST['madd'],
        'fname' => $_POST['fname'],
        'address' => $_POST['address'],
        'relation' => $_POST['relation'],
        'email' => $_POST['email'],
        'namebr' => $_POST['namebr'],
        'snamebr' => $_POST['snamebr'],
        'bodatebr' => $_POST['bodatebr'],
        'fanamebr' => $_POST['fanamebr'],
        'phonebr' => $_POST['phonebr'],
        'nationalitybr' => $_POST['nationalitybr'],
        'addressbr' => $_POST['addressbr'],
        'nameb' => $_POST['nameb'],
        'snameb' => $_POST['snameb'],
        'bodateb' => $_POST['bodateb'],
        'fanameb' => $_POST['fanameb'],
        'phoneb' => $_POST['phoneb'],
        'nationalityb' => $_POST['nationalityb'],
        'addressbrq' => $_POST['addressbrq'],
        'profaddbri' => $profaddbriimage,
        'profaddbgrom' => $profaddbgromimage,
        'brideid' => $brideidimage ,
        'bridegroomid' => $bridegroomidimage,
        'passphotdr' => $passphotdrimage,
        'meecertifi' => $meecertifiimage,
        'previosmarr' => $previosmarrimage,
        'deathcerti' => $deathcertiimage,
        'muslimconver' => $muslimconverimage,
        'wfullname1' => $_POST['wfullname1'],
        'waddress1' => $_POST['waddress1'],
        'wfullname2' => $_POST['wfullname2'],
        'waddress2' => $_POST['waddress2'],
        'deposite' => $amount,
        'paymode' => $_POST['paymode'],
        'tran_id' => '',

		);
		$a = $this->commonmodel->setnikahform($data);
		if($_POST['paymode'] == 'stripe'){
		    redirect('welcome/getstripecard/'.$a.'/nikah');
		}
		if($_POST['paymode'] == 'Paypal'){
		    redirect('paypal?id='.$a.'&data=&nikah');
		}
	}

	//divorce form
	public function divorceform(){
		$config['upload_path'] = './upload/divorce/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_height'] = 1500;
        $config['encrypt_name'] = true;
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('mrrcertif')) {
            $error = array('error' => $this->upload->display_errors());
            redirect('services/divorce-services');
        } else {
            $mrrcertif =  $this->upload->data();
           $mrrcertifimage = $mrrcertif['file_name'];
        }
        if (!$this->upload->do_upload('husbenapss')) {
            $error = array('error' => $this->upload->display_errors());
            redirect('services/divorce-services');
        } else {
            $husbenapss =  $this->upload->data();
           $husbenapssimage = $husbenapss['file_name'];
        }
        if (!$this->upload->do_upload('wifepassport')) {
            $error = array('error' => $this->upload->display_errors());
            redirect('services/divorce-services');
        } else {
            $wifepassport =  $this->upload->data();
           $wifepassportimage = $wifepassport['file_name'];
        }
        if (!$this->upload->do_upload('w1passpoet')) {
            $error = array('error' => $this->upload->display_errors());
            redirect('services/divorce-services');
        } else {
            $w1passpoet =  $this->upload->data();
           $w1passpoetimage = $w1passpoet['file_name'];
        }
        if (!$this->upload->do_upload('w2passpoet')) {
            $error = array('error' => $this->upload->display_errors());
            redirect('services/divorce-services');
        } else {
            $w2passpoet =  $this->upload->data();
           $w2passpoetimage = $w2passpoet['file_name'];
        }
        $data = array(
        'nameh' => $_POST['nameh'],
        'snameh' => $_POST['snameh'],
        'phoneh' => $_POST['phoneh'],
        'bodh' => $_POST['bodh'],
        'addressh' => $_POST['addressh'],
        'overseash' => $_POST['overseash'],
        'hukr' => $_POST['hukr'],
        'natih' => $_POST['natih'],
        'passph' => $_POST['passph'],
        'bornh' => $_POST['bornh'],
        'fnamew' => $_POST['fnamew'],
        'snamew' => $_POST['snamew'],
        'phonew' => $_POST['phonew'],
        'bodw' => $_POST['bodw'],
        'addressw' => $_POST['addressw'],
        'overseasw' => $_POST['overseasw'],
        'wukr' => $_POST['wukr'],
        'natiw' => $_POST['natiw'],
        'passpw' => $_POST['passpw'],
        'bornw' => $_POST['bornw'],
        'fullnamemos' => $_POST['fullnamemos'],
        'certifinumber' => $_POST['certifinumber'],
        'contactdate' => $_POST['contactdate'],
        'email' => $_POST['email'] ,
        'wname1' => $_POST['wname1'],
        'wnation1' => $_POST['wnation1'],
        'wname2' => $_POST['wname2'],
        'wnation2' => $_POST['wnation2'],
        'mrrcertif' => $mrrcertifimage,
        'husbenapss' => $husbenapssimage,
        'wifepassport' => $wifepassportimage,
        'w1passpoet' => $w1passpoetimage,
        'w2passpoet' => $w2passpoetimage,
        'deposite' => $_POST['price'],
        'tran_id' => '',
        'paymode' => $_POST['paymode']

		);
		$a = $this->commonmodel->setdivorceform($data);
		if($_POST['paymode'] == 'stripe'){
		redirect('welcome/getstripecard/'.$a.'/divorce');
		}
        if($_POST['paymode'] == 'Paypal'){
		    redirect('paypal?id='.$a.'&data=&divorce');
		}
	}
	//payapal
	public function setpaypal($id,$cond){
	    if($cond == 'booking'){
			$data['alldata'] = $this->commonmodel->getbookingdata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
		if($cond == 'nikah'){
			$data['alldata'] = $this->commonmodel->getnikahdata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
		if($cond == 'divorce'){
			$data['alldata'] = $this->commonmodel->getdivorcedata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
	    $this->load->view('payaplset',$data);
	}
    
    //stripe
	public function getstripecard($id,$cond)
	{
		if($cond == 'booking'){
			$data['alldata'] = $this->commonmodel->getbookingdata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
		if($cond == 'nikah'){
			$data['alldata'] = $this->commonmodel->getnikahdata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
		if($cond == 'divorce'){
			$data['alldata'] = $this->commonmodel->getdivorcedata($id);
			$data['id'] = $id;
			$data['cond'] = $cond;
		}
		$this->load->view('viewstripecard',$data);
	}
	public function getstripepayment(){

		$payment_id = $statusMsg = ''; 
		$ordStatus = 'error'; 
		if(!empty($_POST['stripeToken'])){ 
		    $token  = $_POST['stripeToken']; 
		    $name = $_POST['name']; 
		    $email = $_POST['email']; 
		    $action_form = $_POST['give_action']; 
		    $itemName = 'Hall Booking';
		    $itemPrice = $_POST['price']; 
		    $id=$_POST['id'];
		    $currency = 'gbp';
		    // Include Stripe PHP library 
		    require_once(APPPATH.'libraries/stripe/init.php');
		    // Set API key 
		    \Stripe\Stripe::setApiKey('sk_test_51Coyv6Fiveg2tuPoleiqJ1mWqxhQfQgzhi62oikv4M0NltmFfg4N9LxHNzIAInwaTQQSBWu7WdxHQnb8l584SKAz00Vbf9sfCZ'); 
    // Add customer to stripe 
    try {  
        $customer = \Stripe\Customer::create(array( 
            'email' => $email, 
            'source'  => $token 
        )); 
    }catch(Exception $e) {  
        $api_error = $e->getMessage();  
    } 
    if(empty($api_error) && $customer){  
        // Convert price to cents 
        $itemPriceCents = ($itemPrice*100); 
        // Charge a credit or a debit card 
        try {  
            $charge = \Stripe\Charge::create(array( 
                'customer' => $customer->id, 
                'amount' => $itemPriceCents,
                'currency' => $currency,
                'description' => $itemName 
            )); 
        }catch(Exception $e) {  
            $api_error = $e->getMessage();  
        } 
        if(empty($api_error) && $charge){ 
            // Retrieve charge details 

            $chargeJson = $charge->jsonSerialize(); 
            // Check whether the charge is successful 
            if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){ 

                // Transaction details  

                $transactionID = $chargeJson['balance_transaction']; 

                $paidAmount = $chargeJson['amount']; 

                $paidAmount = ($paidAmount/100); 

                $paidCurrency = $chargeJson['currency']; 

                $payment_status = $chargeJson['status']; 
                $payment_id = rand(10,1000);

                // If the order is successful
                if($payment_status == 'succeeded'){ 
                    $ordStatus = 'success'; 
                    $statusMsg = 'Your Payment has been Successful!';

                    if($action_form == "booking"){
                    	$this->commonmodel->updatebookingtoken($id,$transactionID);
                    }
                    if($action_form == "nikah"){
                    	$this->commonmodel->updatenikahtoken($id,$transactionID);
                    }
                    if($action_form == "divorce"){
                    	$this->commonmodel->updatedivorcetoken($id,$transactionID);
                    }
                    	redirect('thankyoupayment');
				                }else{ 
				                    $statusMsg = "Your Payment has Failed!"; 
				                    redirect('failedpayment');
				                } 

				            }else{ 
				                $statusMsg = "Transaction has been failed!"; 
				                redirect('failedpayment');
				            } 

				        }else{ 
				            $statusMsg = "Charge creation failed! $api_error";  
				            redirect('failedpayment');
				        } 
				    }else{  
				        $statusMsg = "Invalid card details! $api_error";  
				        redirect('failedpayment');
				    } 
				}else{ 
				    $statusMsg = "Error on form submission."; 
				    redirect('failedpayment');
				} 
	}
}
