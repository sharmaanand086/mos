<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Covid 19 Guidance & Support</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Covid 19 Guidance & Support</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Covid 19 Guidance & Support</a></h2>
                <p>The current NHS advice is that as individuals we should stop <b>non-essential contact</b> (including shaking hands, hugging, kissing) and if we go outside, to keep more than <b>2 metres (3 steps)</b> apart from others. This is part of the UK’s social distancing measures to help slow down the spread of COVID19 – </p><p>

The best way to protect ourselves is to follow good hygiene practices, including:
</p><p>
  <ol>
    <li>
Wash hands frequently with soap/water or hand sanitiser gel</li><li>
Catch coughs and sneezes with disposable tissues</li><li>
Throw away used tissues (then wash hands)</li><li>
If you don’t have a tissue, use your sleeve</li><li>
Avoid touching your eyes, nose and mouth with unwashed hands</li><li>
Avoid close contact with people who are unwell</li>

</ol>
</p><p>
Click here for further guidance and useful graphics.
</p><p>
Much of this advice, and an emphasis on cleanliness and hygiene is in line with Islamic tradition. Abu Malik Al-Ash`ari (may Allah be pleased with him) reported that the Messenger of Allah (peace and blessings be upon him) said: “Purity is half of iman (faith).“ [Muslim]
</p><p>
If you are in any doubt visit ​NHS111 Online​ or call 111. Do not attend your GP practice or pharmacy as this places others at risk. For NHS advice on what self-isolation means, click here.
</p><p>
. Coping with stress during the COVID-19 pandemic</p><p>
Muslim mental health organisations in the UK have united to provide a range of services to tackle mental health problems arising from the coronavirus pandemic.
</p><p>
Each organisation specialises in a different aspect of mental health, and can be contacted as your needs require. More details can be found in the flyer here.
</p><p>
For faith-sensitive and confidential mental health advice, Muslim Youth Helpline offer online chat/email and phone support on 0808 808 2008 available for Muslims of all ages. Inspirited Minds also offer online support. A flyer on mental health support during COVID-19 pandemic can be found here.
</p><p>
The World Health Organisation has published guidelines (PDF) and also produced advice on individuals and communities coping with stress during the COVID-19 outbreak, which includes advice such as the following: 
</p><p>
Maintain a healthy lifestyle – diet, sleep, exercise etc.
Don’t use smoking, alcohol or drugs to deal with emotions
Get the facts from the authorities – do not base your actions on hearsay
Limit worry by lessening time you/your family spend listening to media coverage
Draw on skills you have used in the past to help you manage adversities
</p><p>
Further information on coping with mental health during the COVID-19 outbreak is published by the Mental Health Foundation here.
</p><p>
Beware Fake News! – It is important to verify any news you receive/come across before acting upon it or forwarding on. 
</p><p>
“Fake news” that causes panic is also easily spread during a crisis like this. Educate yourself and your family/friends on avoiding fake news, including 1) Consider the Source, 2) Read Beyond, 3) Cross Check, 4) Don’t forward every message, 5) Check the date and 6) Don’t panic
</p><p>
Prophet Muhammad (peace be upon him): “Seek out the vulnerable among you. Verily, you are only given provision and support due to your support of the weak.” (Tirmidhi).
</p><p>
During this COVID-19 crisis, the socially vulnerable may include those community members who are:
Undertaking social isolation
Elderly (especially if living alone)
Feeling unwell/ill
With disabilities
Economically vulnerable e.g. loss of income source
Single parents with children
No access to a car for transport
Many Muslim institutions, mosques and activists are turning their centers into hubs of volunteer response efforts, including:
picking up shopping from supermarket
picking up prescriptions from pharmacy
delivering a cooked meal
having a friendly conversation
supporting a local foodbank
…and more!
How can you get involved this?
Volunteers – identify able-bodied volunteers who can support those who need support with daily activities e.g. buying food, deliveries. Set-up communication channels and arrange an initial meeting.
Broadcast / Announcements – Tell people that help is available e.g.:
Social Media/WhatsApp announcements
Personal phone calls to community members
Door knocking to neighbours
Regular Check-In – Make a list of socially vulnerable individuals or families in your neighbourhood/community who are likely to need support.
Task your volunteers with keeping in touch with them regularly.
Use voice or video-messaging as well as text/graphic messages to have a stronger and more human connection and maintain morale.
The NHS is recruiting volunteers to support key health care service workers.
Get involved by registering online at: www.goodsamapp.org/NHS
</p><p>
When getting involved, make sure you follow official “How to Help Safely” advice.

 </p><p>

Some more useful links below:
</p><p>
https://www.oneyouhounslow.org/connect-more/
</p><p>
https://www.oneyouhounslow.org/2020/03/23/coping-with-covid-19/
</p><p>
NHS general COVID-19 advice
NHS self-isolation advice
UK Government COVID-19 Recovery Plan (11 May)
Official public health advice
Public Health England advice
Health Protection Scotland advice
Public Health Wales advice
Public Health Agency (Northern Ireland) advice
Public Health England campaign resources (posters, other resources etc)
Muslim communities specialist advice:
British Islamic Medical Association (BIMA) latest guidance
Mental Health – Muslim Youth Helpline (MYH) Practical Guide
Muslim Charities – Practical Guide (MCF)
British Board of Scholars and Imams (BBSI) latest advice
Muslims Lawyers Pro Bono Group
National (Muslim) Burial Council latest advice
Council of British Hajjis UK latest advice to Hajj and Umrah Pilgrims
Other useful advice
Foreign Office travel advice 
Department for Education education setting guidance
Charity Commission COVID-19 guidance for the charity sector
World Health Organisation (WHO) advice on coping with stress
Mental Health Foundation advice on coping with stress</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
