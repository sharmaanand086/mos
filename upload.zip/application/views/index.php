<?php include('header.php'); ?>
  
  <!--Banner-->
  <div id="banner">
    <div class="owl-carousel" id="home-slider">
        <div class="item">
            <div class="caption" style="top: 0;">
             <video style=" width: 100%; " class="resizelistener" id="myVideo" loop autoplay>
              <source src="<?php echo base_url(); ?>assets/images/video/mos.mp4" type="video/mp4"></video>
            </div>
         </div>
      <div class="item">
        <div class="caption">
          <div class="container"> <span><img src="<?php echo base_url(); ?>assets/images/kalma-text-img.png" alt="kalma"></span> <strong class="title">As-Salaamu Alaikum</strong>
            <h1 style="line-height: 1;">Allah and his angels send blessings on the prophet</h1>
            <h4 style="color:#fff">O you who believe! send your blessings on him.and salute him with all respect.</h4>
            <!-- <div class="btn-row"><a href="#" class="btn-style-1">read more</a></div> -->
          </div>
        </div>
        <img class="bannerimg" src="<?php echo base_url(); ?>assets/images/s1.png" alt="banner"> </div>
        
    </div>
  </div>
  <!--Banner--> 
  
  <!--Mian Content-->
  <div id="main"> 
    <!--History Section-->
    <section class="history-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-sm-6">
            <div class="frame"><img src="<?php echo base_url(); ?>assets/images/a1.png" alt="history"></div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="text-box">
              <div class="heading-left">
                <h2>About the Mosque</h2>
              </div>
              <b>In The Name Of Allah The Beneficent The Merciful </b>
              <p>Hounslow Jamia Masjid & Islamic Centre is the largest purpose built Mosque in West London. We believe that our primary role is to serve the needs of the local community and to work towards the common good. Our strong partnerships with the London Borough of Hounslow Council, Hounslow Primary Care Trust, the Metropolitan Police, other faith groups and many others have helped us to contribute towards improvements within the local community. This builds on the very essence of our Mosque: a coming together of distinguished Muslims and non-Muslims to create a cohesive and tolerant society.
      </p>
              <a href="<?php echo base_url(); ?>about-us" class="btn-style-1">Read More</a> </div>
          </div>
        </div>
      </div>
    </section>
    <!--History Section--> 
    
    <!--Our Vision-->
    <section class="our-vision">
      <div class="container">
        <div class="heading-center">
          <h2>News</h2>
          <div class="text-holder" style="display: none;">
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor 
              aliquet. Aenean sollicitudin.</p>
          </div>
        </div>
        <div class="row">
          <?php
          foreach($news as $new){
          ?>
          <div class="col-md-4 col-sm-4">
            <div class="vision-box" onclick="window.location.href='<?php echo base_url(); ?>news/<?= $new->id ?>/<?= preg_replace('/[^A-Za-z0-9\-]/', "",str_replace(" ","-",$new->title)) ?>'" style="cursor: pointer;"> 
              <img id="ctl00__latest_news1_Repeater1_ctl00_imgThumb" src="<?= $new->image ?>" alt="Mosque reopening 2nd December" style="margin-bottom: 5%;">
              <h3><a><?= $new->title ?></a></h3>
              <p><?= $new->short_desc; ?></p>
            </div>
          </div>
          <?php } ?>
        </div>
        <div class="btn-row" style="margin-top: 2%;"><a href="<?php echo base_url(); ?>allnews" class="btn-style-1">News Archive</a></div>
      </div>
    </section>
    <!--Our Vision--> 
    
    <!--Parallax Section-->
    <section class="parallax-section" style="background: url(<?php echo base_url(); ?>assets/images/s2.png) no-repeat left top/cover;">
      <div class="container">
        <div class="right-box"> <img src="<?php echo base_url(); ?>assets/images/parallax-text.png" alt="text"> <strong class="title">Then which of the favors of your Lord will ye deny?</strong> <a href="#">{ Quran: 55 13 }</a> </div>
      </div>
    </section>
    <!--Parallax Section--> 
    
    <!--Event Section-->
    <section class="event-section">
      <div class="container">
        <div class="heading-center"> 
          <h2>Our Events</h2>
          <!-- <div class="text-holder">
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor 
              aliquet. Aenean sollicitudin.</p>
          </div> -->
        </div>
        <div class="row">
          <?php
          foreach($events as $event){
         $newtitle = preg_replace('/[^A-Za-z0-9\-]/','',str_replace(" ","-",$event->title));
          ?>
          <div class="col-md-4 col-sm-4">
            <div class="vision-box" onclick="window.location.href='<?php echo base_url(); ?>event/<?= $event->id ?>/<?= $newtitle ?>'" style="cursor: pointer;">
              <img id="ctl00__latest_news1_Repeater1_ctl00_imgThumb" src="<?php echo base_url(); ?>assets/images/event/<?= $event->image ?>" alt="Mosque reopening 2nd December" style="margin-bottom: 5%;">
              <h3><a href="<?php echo base_url(); ?>event/<?= $event->id ?>/<?= preg_replace('/[^A-Za-z0-9\-]/', '',str_replace(" ","-",$event->title)) ?> "><?= $event->title ?></a></h3>
            </div>
          </div>
        <?php } ?>
        </div>
        <div class="btn-row" style="margin-top: 2%;"><a href="<?php echo base_url(); ?>allevent" class="btn-style-1">Read more</a></div>
      </div>
    </section>
    <!--Event Section-->
    
    <section class="pillars-islam-section">
      <div class="container">
        <h2>Pillars Of Islam</h2>
        <div class="pillar-box">
          <div class="shape-1"><img src="<?php echo base_url(); ?>assets/images/features-icon-3.png" alt=""></div>
          <h3>Kalma</h3>
        </div>
        <div class="pillar-box">
          <div class="shape-1"><img src="<?php echo base_url(); ?>assets/images/features-icon-1.png" alt=""></div>
          <h3>Salat</h3>
        </div>
        <div class="pillar-box">
          <div class="shape-1"><img src="<?php echo base_url(); ?>assets/images/features-icon-4.png" alt=""></div>
          <h3>Zakat</h3>
        </div>
        <div class="pillar-box">
          <div class="shape-1"><img src="<?php echo base_url(); ?>assets/images/features-icon-5.png" alt=""></div>
          <h3>Fasting</h3>
        </div>
        <div class="pillar-box">
          <div class="shape-1"><img src="<?php echo base_url(); ?>assets/images/features-icon-6.png" alt=""></div>
          <h3>Hajj</h3>
        </div>
      </div>
    </section>
    
    <!--Gallery Style 1-->
    <section class="gallery-style-1">
      <div class="container">
        <div class="heading-center"> 
          <h2>salat islamic photo gallery</h2>
          <!-- <div class="text-holder">
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor 
              aliquet. Aenean sollicitudin.</p>
          </div> -->
        </div>
        <div class="row gallery">
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a13.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a13.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a2.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a2.jpg" class="zoom" data-rel="prettyPhoto[gallery2]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a3.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a3.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a14.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a14.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a5.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a5.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a15.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a15.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a7.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a7.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/a16.jpg" alt="gallery">
              <div class="caption">
                <h3><a href="#">Eid Mela</a></h3>
                <a href="<?php echo base_url(); ?>assets/images/gallery/a16.jpg" class="zoom" data-rel="prettyPhoto[gallery1]"><i class="fa fa-expand" aria-hidden="true"></i></a> </div>
            </div>
          </div>
        </div>
        <div class="btn-row"><a href="<?php echo base_url(); ?>photo/1" class="btn-style-1">load more</a></div>
      </div>
    </section>
    <!--Gallery Style 1--> 
    
    <!--Donation Section-->
    <section class="donation-section" style="background: url(<?php echo base_url(); ?>assets/images/s3.png) no-repeat left top/cover;">
      <div class="container">
        <div class="heading-center"> <strong class="title">Your Donation</strong>
          <h2>restoration of grand mosque</h2>
          <div class="text-holder">
            <!--<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor -->
            <!--  aliquet. Aenean sollicitudin.</p>-->
          </div>
        </div>
        <!--<div class="progress-box">-->
        <!--  <div class="progress">-->
        <!--    <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;"> 50% </div>-->
        <!--  </div>-->
        <!--</div>-->
        <strong class="title-2">we need your donation for mosque</strong>
        <div class="btn-row"><a href="<?php echo base_url(); ?>donation" class="btn-style-1">donate now</a></div>
      </div>
    </section>
    <!--Donation Section--> 
    <section class="prayer-timings">
      <div class="container">
        <h2>Prayer Timings</h2>
        <div class="row">
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Fajr</h3>
                  <span>Dawn Prayer</span> <b><?= $pray[0]->FajrStart ?></b> </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Sunrise</h3>
                  <span>Sunrise Time</span> <b><?= $pray[0]->SunRise ?></b> </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Dhuhr</h3>
                  <span>Noon Prayer</span> <b><?= $pray[0]->SunRise ?></b> </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Asr</h3>
                  <span>Afternoon Prayer</span> <b><?= $pray[0]->AsrStart ?></b> </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Maghrib</h3>
                  <span>Sunset Prayer</span> <b><?= $pray[0]->MaghribStart ?></b> </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-4">
            <div class="timing-box">
              <div class="shape-1">
                <div class="text-holder">
                  <h3>Isha</h3>
                  <span>Evening Prayer</span> <b><?= $pray[0]->IshaStart ?></b> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!--Mian Content--> 
  <?php include('footer.php'); ?>