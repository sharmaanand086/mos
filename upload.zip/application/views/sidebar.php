<!-- side bar -->
          <div class="col-md-4 col-sm-5">
            <aside>
              <div class="sidebar">
                <div class="sidebar-box">
                  <div class="timetable" style="background-color: #f8f8f8;">
                        <div style="padding: 15px 2%;border-bottom: 1px solid #e7e7e7;">
                          <h4 style="font-weight: 600;color: #ffad05;text-align:center">Prayer Timetable</h4> <p style="margin: 0;color: #000;text-align:center"><span style="font-size:15px;"><?= date('d/m/Y'); ?>,<br> 21 Jumaad-Al-Awwal - 1442 AH</span></p>
                        </div>
                        <div class="dark salah">
                            <div class="td4">Salah</div>
                            <div class="td4">Begins</div>
                            <div class="td4">Jama'ah</div>
                        </div>
                        <div class="dark">
                            <div class="td4">Fajr</div>
                            <div class="td4"><?= $pray[0]->FajrStart; ?></div>
                            <div class="td4"><?= $pray[0]->FajrJamaat; ?></div>
                        </div>
                        <div class="dark">
                            <div class="td4">Zuhr</div>
                            <div class="td4"><?= $pray[0]->ZuhrStart; ?></div>
                            <div class="td4"><?= $pray[0]->ZhurJamaat; ?></div>
                        </div>
                        <div class="dark">
                            <div class="td4">Asr</div>
                            <div class="td4"><?= $pray[0]->AsrStart; ?></div>
                            <div class="td4"><?= $pray[0]->AsrJamaat; ?></div>
                        </div>
                        <div class="dark">
                            <div class="td4">Magrib</div>
                            <div class="td4"><?= $pray[0]->MaghribStart; ?></div>
                            <div class="td4"><?= $pray[0]->MaghribJamaat; ?></div>
                        </div>
                        <div class="dark">
                            <div class="td4">Isha</div>
                            <div class="td4"><?= $pray[0]->IshaStart; ?></div>
                            <div class="td4"><?= $pray[0]->IshaJamaat; ?></div>
                        </div>
                        <!-- <div class="dark"><div class="td4">Juma</div><div class="td4"><?= $pray[0]->ZuhrStart; ?></div><div class="td4"><?= $pray[0]->ZuhrStart; ?></div></div> -->
                    </div>
                    
                </div>
                <div class="sidebar-box view-tt">
                      <a href="<?php echo base_url(); ?>prayertimetable/<?= date('F'); ?>" style="text-decoration: none;">View Monthly Timetable</a>
                    </div>
                <div class="sidebar-box">
                  <h3>SUBSCRIBE TO OUR UPDATES</h3>
                    <p>Get the latest news and updates direct to your email</p>
                  <form>
                    <input style="margin-bottom: 4%;" id="name" placeholder="Enter your Name" required type="text">
                    <input style="margin-bottom: 4%;" id="email" placeholder="Enter your Email" required type="text">
                    <input style="margin-bottom: 4%;" id="phone"  placeholder="Enter your Phone" required type="number">
                    <button id="subscribe" style="position: unset;width: 100%;" type="submit" value="Subscribe">Subscribe</button>
                    <p style="color: green;display: none;" id="succmsg">Thank Yoy for your subscribe</p>
                  </form>
                </div>
                
                <div class="sidebar-box">
                  <img id="ctl00__latest_news1_Repeater1_ctl00_imgThumb" src="<?php echo base_url(); ?>assets/images/event/a1.jpg" alt="Mosque reopening 2nd December" style="margin-bottom: 5%;width: 100%;">
                </div>
                <div class="sidebar-box">
                  <img id="ctl00__latest_news1_Repeater1_ctl00_imgThumb" src="<?php echo base_url(); ?>assets/images/event/ev1.jpg" alt="Mosque reopening 2nd December" style="margin-bottom: 5%;width: 100%;">
                </div>
              </div>

              </div>
            </aside>
          </div>
          <!-- side bar ev1 -->