<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Mosque History & Objectives</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>about-us">About Us</a></li>
        <li class="active">Mosque History & Objectives</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Mosque History & Objectives</a></h2>
                <p>
                  <h4 style="font-weight: 800;margin-bottom: 2px;margin-top: 4%">Beginning</h4>
Hounslow Jamia Masjid & Islamic Centre is the largest purpose built Mosque in West London. We believe that our primary role is to serve the needs of the local community and to work towards the common good. Our strong partnerships with the London Borough of Hounslow Council, Hounslow Primary Care Trust, the Metropolitan Police, other faith groups and many others have helped us to contribute towards improvements within the local community. This builds on the very essence of our Mosque: a coming together of distinguished Muslims and non-Muslims to create a cohesive and tolerant society.
</p><p>
<h4 style="font-weight: 800;margin-bottom: 2px">Promoting Tolerance and Opposing Extremism</h4>
Hounslow Jamia Masjid & Islamic Centre works actively to promote tolerance and understanding. Along with all the local Mosques, we are a member of the West London Mosque Forum; this binds together Muslims from different backgrounds and strands of Islam. We enjoy excellent interfaith relations – such as our recent interfaith events – and several times each year we open the doors of the Mosque and centre, inviting people to visit and view an exhibition about Islam and Muslims
</p><p>
<h4 style="font-weight: 800;margin-bottom: 2px">Hounslow Masjid</h4>
Since the Mosque’s erection, it has become a focal point for the Muslim community. Over the years, Muslims have used the Mosque for events, meetings, lectures, studies and community and educational purposes. Many of the original founders of the Mosque committee still have a connection with the Mosque and as time has passed, many new innovations have been made as to how the Mosque is democratically run using Islamic teachings as the basis for equal representation of all members of the community. Thus, regular meetings, annual selection and equal opportunities have meant that the running of Hounslow Jamia Masjid has been as efficient as possible over the decades.
</p><p>
<h4 style="font-weight: 800;margin-bottom: 2px">Mosque Design</h4>
The Mosque itself has two floors. On the first floor there is a purpose built primary school and a large main hall for prayers which can accommodate 500 worshippers at any one time. In addition, there is a ladies gallery to accommodate approximately 400 women. New contracts have recently been given to extend the Mosque as well as provide extra separate accommodation for visitors t the Mosque who drop in to learn about Islam and Muslims. The ground floor is divided into two areas providing a community hall, an extensive Islamic library, and the main prayer hall for men. On special days like Eid, when demand is high, both the main prayer hall and the upstairs hall are used for prayers providing accommodation for 5000 people. On Eid day, there are four prayer services during which between 10,000 to 15,000 worshippers visit the Mosque for the special services, and on Fridays the gathering is 4000 plus. This is excluding the frequent attendance of international visiting groups and mainstream media personnel.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
