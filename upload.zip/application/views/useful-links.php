<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>useful links</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo  base_url(); ?>">Home</a></li>
        <li><a >Resources</a></li>
        <li class="active">Useful Links</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>useful links</a></h2>
                <p>
    <a class="atagclass" target="_blank" href="http://www.halalhmc.org/">Halal Monitoring Committee</a></p>
    <p><a class="atagclass" target="_blank" href="http://www.kitaba.org/">Promoting the well being of visually impaired Muslims</a></p>
    <p><a class="atagclass" target="_blank" href="http://www.livingislam.org/">Traditional Islam</a></p>
    <p><a class="atagclass" target="_blank" href="http://hspc-org.uk/">Hounslow Social &amp; Political Committee</a></p>
    <p><a class="atagclass" target="_blank" href="http://www.shukr.co.uk/">Islamic Clothing</a></p>
    <p><a class="atagclass" target="_blank" href="http://shop.essentialislam.co.uk/">Decor and gifts for the home</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.nhs.uk/oneyou/every-mind-matters/coronavirus-covid-19-staying-at-home-tips/">Coronavirus and looking after your health</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.youtube.com/channel/UCYewTa7N81C9ekpiYaXQzjw/videos">Finding yourself in these troubled times</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.sarainternationaltravel.com/">Hajj, Umrah &amp; Religious Tours</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.guidancehub.org/">Activities and Courses for people up North</a></p>
    <p><a class="atagclass" target="_blank" href="https://imanproject.uk/">Pledge towards Salawat recital or a global Quran completion</a></p>
    <p><a class="atagclass" target="_blank" href="http://nicheoflights.co.uk/about/">Sufism and its relevance in modern time</a></p>
    <p><a class="atagclass" target="_blank" href="http://www.remembrancepublications.co.uk/">Books and CDs</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.oneyouhounslow.org/eat-well/">Eat well (ensure what you purchase is halal)</a></p>
    <p><a class="atagclass" target="_blank" href="https://www.tarteelequran.com">Learn Quran Online</a></p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
