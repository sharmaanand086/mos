<?php include('header.php'); ?>
    <!--Wrapper Content Start-->
    <div id="inner-banner" style="    padding: 67px;">
   
  </div>
    <div id="wrapper" class="thankclass">
      <!--Main Content Start-->
      <div class="main-content">
        <!-- Start of Thank -->
          <section class="container">
              <div class="error-page">
                <div class="holder">
                  <h1>Transaction Failed
                  </h1>
                  <p>
                  </p>
                </div>
              </div>
          </section>
        <!-- End of Thank --> 
      </div>
	</div>
    </body>
</html>
