<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Video Gallery</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a>Media</a></li>
        <li class="active">Video Gallery</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Video Gallery</a></h2>
              </div>
            </div>
              <div class="post-box-new mr-div">
                <div>
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/3HQ0EOfvlpA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                </div>
                <div class="text-box">
                  <h4><a>Fasting Ramadan & Fighting the Coronavirus</a></h4>
                  <p>A special address by Shaykh Muhammad Al-Yaqoubi</p>
                </div>
              </div>
              <div class="post-box-new ml-div">
                <div>
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/5PxyVcuUaV8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                </div>
                <div class="text-box">
                  <h4><a>Remembrance of Death & The Afterlife</a></h4>
                  <p>A glimpse at the Book by Imam Ghazali taught by Shaykh Zaheer</p>
                </div>
              </div>
              
              <div class="btn-row" style="/* margin-top: 2%; */"><a href="https://www.youtube.com/hounslowjamiamasjid" target="_blank" class="btn-style-1">View More</a></div>
              
            <!--EVENT POST END--> 
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
