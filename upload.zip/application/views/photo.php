<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Photo GALLERY</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a >Media</a></li>
        <li class="active">Photo Gallery</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--BLOG START-->
    <section class="gallery-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="row gallery owngallery">
              <?php foreach($photo as $row): ?>
          <div class="col-md-4 col-sm-4">
            <div class="frame"> <img src="<?php echo base_url(); ?>assets/images/gallery/<?= $row->image ?>" alt="img" style="width: 300px;"> <a href="<?php echo base_url(); ?>assets/images/gallery/<?= $row->image ?>" class="link" data-rel="prettyPhoto[gallery1]"><i class="fa fa-image" aria-hidden="true"></i></a> </div>
          </div>
        <?php endforeach; ?>
        </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
