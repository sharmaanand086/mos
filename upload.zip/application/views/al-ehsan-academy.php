<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Al-Ehsan Academy</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a >Education</a></li>
        <li class="active">Al-Ehsan Academy</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Al-Ehsan Academy</a></h2>
                <p>***NEW MADRASSA WEBSITE***
</p><p>
Please visit www.alehsanacademy.co.uk to enrol your child and learn more about the Academy.
</p><p>
Sura Hijr - Verse 9. Allah Almighty says: "We have without doubt, sent down the message and we will assuredly guard it from corruption."
</p><p>
It is mentioned in the noble Hadith: "The best amongst you is the one who learns the Quran and teaches it to others".
</p><p>
Islamic education is the cornerstone of being a good Muslim and citizen. Hounslow Jamia Masjid is dedicated to this cause and offers education classes for children. Deen School believes that success for any of our students can be achieved through appropriate behaviours and attitudes. The school aims to provide the framework of affirmative, positive and caring discipline through effective and timely intervention.
</p><p>
Students will be actively praised for positive action: Excellent work, acts of kindness and consideration, good effort and excellent attendance.
</p><p>
Staff members have a clear responsibly to encourage and positively enforce the accepted standards of discipline.
</p><p>
The school's policy, which states the aims, principles and strategies for discipline at Deen School outlines to all students undergoing their education at Deen School what will be accepted and what will not be accepted. It also aims to promote self control, respect for all members of staff, books and most importantly the Mosque. We expect the students to conduct themselves in a manner which will be a credit to themselves, their parents and our school.
</p><p><b>AIMS</b>

</p><p>
  <ul>
    <li>
Students are able to understand the role and need for discipline as a positive part of school life.</li><li>
Students are able to study in a safe, comfortable atmosphere.</li><li>
Students learn to respect one another.</li><li>
Students develop a responsible and independent attitude.</li><li>
A clear communication with parents of the discipline policy of the school; Parents and students should be aware clearly of the punishment that can be administered and also the responsibility of the parents in the interaction with the school.</li><li>
Pupils are made aware that there is a partnership between the home and school.</li>
  </ul>
</p><p>
Students follow a structured syllabus throughout their time at the Madrassa and progress is assessed annually through oral and written examinations. The majority of Islamic books used by the students are written in English. Students are also taught Arabic and 'Tajweed', the correct pronunciation of the Holy Quran in Arabic.
</p><p>
Hounslow Jamia Masjid runs the Islamic Education classes daily. Classes run between 4.30pm and 6pm and then from 6pm to 7.30pm during the weekdays. On weekends classes run between 10am and 12pm and then from 12.30m to 2.30pm. Further information on any of the above classes can be obtained from the Imam's office.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
