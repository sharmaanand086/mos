<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Visits & Tours</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Visits & Tours</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Visits & Tours</a></h2>
                <p>Throughout the year we receive visitors from various organisations and establishments who travel from all around the world to see the Mosque. A great deal of visitors are from faith, inter-faith and educational institutions wishing to further their understanding of Islamic lifestyle and worship. Tourists make up a large part of the international visitors along with foreign students and delegations from Europe, the Americas, Africa, the Middle-East and Asia.
</p><p>
A normal visit consists of an observation of prayer, a tour of the Mosque building and a Q&A or discussion session. Light refreshments are also provided for younger visitors.
</p><p>
To book a visit, please email: visit@hounslowmasjid.co.uk</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
