<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css" />
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Slider Image 
      
      </h1>
    </section>
    <section class="content">
      
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>Name</th>
                      <th>Image</th>
                       
                    </tr>
                    <?php
                    if(!empty($usersliderRecords))
                    {
                        foreach($usersliderRecords as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->name ?></td>
                      <td><img class="profile-user-img img-responsive "  style="width: 50%;" src="<?php echo base_url(); ?>assets/slider/images/<?php echo $record->imagename ?>" alt="<?php echo $record->imagename ?>"></td>
                       
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
 