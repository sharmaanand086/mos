<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Funeral Services</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>/services">SERVICES</a></li>
        <li class="active">Funeral Services</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Funeral Services</a></h2>
                <p>Funeral prayer services (Janāzah) are held at the Mosque and can be arranged via the main office. We conduct the preparation of bodies for funerals/burials and the coffin and have all the facilities to wash the deceased or maintain their cadaver in cold storage. The Mosque ensures that the service aspect of a funeral is carried out as best as possible before the departed is taken to the graveyard.
</p><p>
  <ul>
    <li>Full Catering services.</li><li>
Sitting Halls (Separate for men & women).</li><li>
Very reasonable charges.</li><li>
Huge car parking facilities.</li><li>
Easily accessible from all parts of the city.</li><li>
Washing & Storage Facilities.</li><li>
‘Khatams’ & ‘Kuls’ facilities.</li><li>
Round the clock 24 Hour-Reliable service</li>

</ul>
</p><p>
Our funeral services will include all below: Taking body from home or hospital to funeral services
</p><p>
  <ul>
<li>Obtaining cause of death/disease free certificate from GP or hospital</li><li>
Obtaining coroner’s report for sending bodies abroad</li><li>
Transportation from home to mortuary – cemetery or airport</li><li>
Assisting in travelling arrangements</li>
</ul>
</p><p>
Please check out our extensive funeral guide below:
</p><p><b>
*** Due to Covid-19 please note there are restrictions on condolence gatherings, members of family attending the shrouding and also the funeral prayer. Please respect these new guidelines which are for the safety of all Please call 07507 272786 or 07889 725704 in case of any queries ***</b>
</p><p>
<a href="<?php echo base_url(); ?>assets/upload/Funeral_Guide_HJM.pdf" class="atagclass">Funeral_Guide_HJM.pdf</a>
</p><p><b>
Funeral Fund</b>
</p><p>
Hounslow Jamia Masjid & Islamic Centre Funeral Fund (HJMFF) is pleased to offer funeral plans for all Muslims who reside within the London Borough of Hounslow. The HJMFF service shall make all relevant arrangements for undertaking of the funeral. Before you become a member please read & agree to the terms and conditions set by the HJMFF as per below form. Please submit to the admin or main office. Receipt shall be provided
</p><p>
<a class="atagclass" href="<?php echo base_url(); ?>assets/upload/JUNE_2020_HOUNSLOW_JAMIA_MASJID_FUNERAL_FUNDS_MEMEBERSHIP.docx">HOUNSLOW_JAMIA_MASJID_FUNERAL_FUNDS_MEMBERSHIP_FORM_FINAL.docx</a></p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
