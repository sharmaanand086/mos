<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Hounslow Jamia Masjid and Islamic Centre</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/responsive.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/color.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/audioplayer.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/prettyPhoto.css" rel="stylesheet" type="text/css">
<style type="text/css">
  .atagclass{
    outline: none;
    color: #003471;
  }
  .img-box{
    width: 9%;
    display: inline-block;
    vertical-align: top;
    padding-top: 1%;
    text-align: center;
  }
  .main-box{
    width: 90%;
    display: inline-block;

  }
  .title-download{
    margin: 0 0 5px 0;
    font-size: 1.3em;
    font-weight: 700;
  }
  .desc-download{
    line-height: 15px;
  }
  .extrabox{
    margin-bottom: 2%;
  }
  .post-box-new{
    float: left;
    width: 48%;
    margin: 0 0 50px 0;
  }
  .mr-div{
    margin-right: 1%;
  }
  .ml-div{
    margin-left: 1%;
  }
  .post-box-new iframe{
    height: 240px;
  }
  .companymade:hover, .companymade:focus{
    text-decoration: none;
  }
  .td4{
    border-bottom: 1px solid #e7e7e7;
    border-left: 1px solid #e7e7e7;
    margin: 0 !important;
    width: 33.3333%;
    float: left;
    padding: 12px;
    text-align: center;
    font-family: Arial;
    background-color: #f8f8f8;
  }
  .salah{
    font-weight: 700;
  }

    .StripeElement {
  box-sizing: border-box;

  height: 40px;

  padding: 10px 12px;

  border: 1px solid transparent;
  border-radius: 4px;
  background-color: white;

  box-shadow: 0 1px 3px 0 #e6ebf1;
  -webkit-transition: box-shadow 150ms ease;
  transition: box-shadow 150ms ease;
}

.StripeElement--focus {
  box-shadow: 0 1px 3px 0 #cfd7df;
}

.StripeElement--invalid {
  border-color: #fa755a;
}

.StripeElement--webkit-autofill {
  background-color: #fefde5 !important;
}
.thankclass{
      max-height: 100vh;
    height: 100vh;
    padding-top: 20%;
    text-align: center;
}
.abouttitle{
  margin-bottom: 0;
  color: #000;
}
.owngallery{
  display: flex;
  flex-wrap: wrap;
}
small{
  color: red !important;
}
.dawhimg{
    width:100%;
}
.mainboxda{
    margin: 2% 0;
    padding: 3% 3%;
    box-shadow: 2px 2px 13px #888888;
}
.titleda{
        font-weight: bold;
    color: #000;
}
.linkda{
    cursor: pointer;
    color: #026d97;
    font-size: 16px;
    font-weight: 900;
}
.hrdawa{
    width: 28%;
    margin: 20px 0;
    border-top: 3px solid #c9a06a;
}
.ownconta{
    display: flex;
}
.toptitle{
    font: 300 18px/18px 'Roboto', sans-serif;
    margin: 3% 0;
    line-height: 1.4em;
    font-size: 26px;
    text-align: center;
    font-weight: 600;
}
.donown{
    padding:0;
    margin:0;
}
.fstsectiond{
    background-color: #2ca5de;
    padding: 1% 0;
    text-align: center;
}
.fsecptga{
    margin: 0;
    font-size: 20px;
    color: #000;
    font-family: 'Roboto';
}
.fsecspntag{
    font-size: 22px;
    font-weight: 900;
}
.commomdiv{
        background-color: #006a9e;
        text-align: center;
        max-height: 70px;
    height: 70px;
}
.donatbutton{
        background: #00a1d5;
    border-radius: 35px;
    padding: 14px 50px;
    border: none;
    color: #fff;
    margin: 2% 0;
}
.minputsec{
    padding: 20px;
}
.comrdio{
    margin: 0px 0 0px 6px;
    font-size: 19px;
    cursor: pointer;
    color:#fff;
}
</style>
</head>

<body>
<div id="wrapper"> 
  <!--Header-->
  <header id="header">
    <div class="container"> <a href="<?php echo base_url(); ?>" class="logo"><img class="mylogo" src="<?php echo base_url(); ?>assets/images/logo-old.png" alt="logo" style="width: 79%;"></a>
      <div class="header-right">
        <div class="navigation-row">
          <nav class="navbar navbar-inverse">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav" id="nav">
                <li><a href="<?php echo base_url(); ?>">Home</a></li>
                <li><a class="menuclass" href="<?php echo base_url(); ?>about-us">About Us<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo base_url(); ?>about-us/mosque-staff">MOSQUE STAFF</a>
                    </li>
                    <li><a href="<?php echo base_url(); ?>about-us/mosque-history-objectives">Mosque History & Objectives</a></li>
                  </ul>
                </li>
                <li ><a class="menuclass" href="<?= site_url('services') ?>">Services<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?= site_url('services/facilities') ?>">Facilities</a></li>
                    <li><a href="<?= site_url('services/youth') ?>">Youth</a></li>
                    <li><a href="<?= site_url('services/courses-events') ?>">Courses & Events</a></li>
                    <li><a href="<?= site_url('services/funeral-services') ?>">Funeral Services</a></li>
                    <li><a href="<?= site_url('services/marriage') ?>">Marriage</a></li>
                    <li><a href="<?= site_url('ask-IMAM') ?>">Ask IMAM</a></li>
                    <li><a href="<?= site_url('islamic') ?>">Islamic Will Services</a></li>
                    <li><a href="<?= site_url('services/counselling') ?>">counselling</a></li>
                    <li><a href="<?= site_url('services/interfaith') ?>">interfaith</a></li>
                    <li><a href="<?= site_url('services/sisters') ?>">Sisters</a></li>
                    <li><a href="<?= site_url('services/new-muslims') ?>">New Muslims</a></li>
                    <li><a href="<?= site_url('services/visits-tours') ?>">Visits & Tours</a></li>
                    <li><a href="<?= site_url('services/divorce-services') ?>">Divorce Services</a></li>
                    <li><a href="<?= site_url('services/covid-19-guidance-support') ?>">Covid 19 Guidance & Support</a></li>
                    <li><a href="<?= site_url('services/jummah-booking') ?>">jummah booking</a></li>
                    <li><a href="<?= site_url('services/imam-dua-before-death') ?>">Imam Dua Before Death</a></li>
                    <li><a href="<?= site_url('booking') ?>">Booking Hall</a></li>
                  </ul>
                </li>
                <li><a class="menuclass"> Education<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo base_url(); ?>education/al-ehsan-academy">Al-Ehsan Academy</a></li>
                    <li><a href="<?php echo base_url(); ?>education/suffah-primary-school">SUFFAH PRIMARY SCHOOL</a></li>
                  </ul>
                </li>
                <li><a class="menuclass">Media<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo base_url(); ?>media/video-gallery">Video Gallery</a></li>
                    <li><a href="<?php echo base_url(); ?>photo/1">Photo Gallery</a></li>
                  </ul>
                </li>
                <li><a class="menuclass">Resources<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?= site_url('download') ?>">Downloads</a></li>
                    <li><a href="<?php echo base_url(); ?>useful-links">USEFUL LINKS</a></li>
                  </ul>
                </li>
                <li><a href="<?php echo base_url(); ?>donation">Donation</a></li>
                <li><a href="<?php echo base_url(); ?>hounslow-outreach-project">Outreach Project</a></li>
                <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!--Search Bar-->
    <div class="overlay overlay-contentscale">
      <button type="button" class="overlay-close">Close</button>
      <div class="search-inner">
        <form method="get">
          <input type="text" placeholder="Search....." required>
          <button class="submit"><i class="fa fa-search"></i></button>
        </form>
      </div>
      <!--Search Bar Inner--> 
    </div>
    <!--Search Bar--> 
  </header>
  <!--Header--> 