<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Courses & Events</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>/services">SERVICES</a></li>
        <li class="active">Courses & Events</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Courses & Events</a></h2>
                <p>Please visit the homepage for the current courses. And also the image gallery for previous events and courses.
</p><p>
We have held:
</p><p>
Aqidah Intensives
</p><p>
Tajweed classes
</p><p>
Tafsir classes
</p><p>
Youth workshops
</p><p>
Alim & Alimah classes
</p><p>
Urdu classes
</p><p>
Basic Arabic
</p><p>
40 Hadith of Imam Nawawi
</p><p>
In the Defence of the Sunnah
</p><p>
Marriage Seminar
</p><p>
Funeral Seminar
</p><p>
And more Alhumdulillah.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
