<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>counselling</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Counselling</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>counselling</a></h2>
                <p>Counselling is available to those experiencing problems or those wanting advice on specific topics. An appointment will have to be made with the counsellor in advance by completing the attached form and submitting to:
</p><p>
support@hounslowmasjid.co.uk or info@hounslowmasjid.co.uk or bringing in person to the Imam's office
</p><p>
<a class="atagclass" href="<?php echo base_url(); ?>/assets/upload/HJM_Submission_Form.pdf">HJM_Submission_Form.pdf</a></p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
