<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Suffah Primary School</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a>Education</a></li>
        <li class="active">Suffah Primary School</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Suffah Primary School</a></h2>
                <p>Suffah Primary School is an Ofsted registered school and is part of Hounslow Jamia Masjid & Islamic Centre. It is managed by an Education Committee comprising of the Head teacher and Trust members. The school is dependent solely on contributions from donors.
</p><p>
The school views itself very much as part of the local community in the same way as Christian and Jewish faith schools.
</p><p>
The school follows the National Curriculum with special emphasis on Islamic values and teachings. Well educated Muslim children have a great deal to offer British society.
</p><p>
Suffah Primary School aims (Insha'Allah) to develop and maintain high standards of both teaching and learning through strong commitment from teachers, pupils and parents, supported by the wider community and through constant reviews and development of policy enhancements and working practices.
</p><p>
Insha'Allah we aim to make this collaborative teamwork and dedication the foundation of a high quality primary school which becomes a centre of excellence in Islamic education.
</p><p>
For further information please contact the <b>School Bursar</b> on <b>020 8572 9817</b> or visit Suffah Primary School Website</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
