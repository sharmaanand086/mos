<?php include('header.php'); ?>
  
  <!--Banner-->
  <div id="banner">
    <div class="owl-carousel" id="home-slider">
        <div class="item">
        <div class="caption" style="top: 0;">
         <video style=" width: 100%; " class="resizelistener" id="myVideo" loop preload="auto">
          <source src="<?php echo base_url(); ?>assets/images/video/mos.mp4" type="video/mp4" ></video>
        </div>
         </div>
      <div class="item">
        <div class="caption">
          <div class="container"> <span><img src="<?php echo base_url(); ?>assets/images/kalma-text-img.png" alt="kalma"></span> <strong class="title">As-Salaamu Alaikum</strong>
            <h1>Allah and his angels send blessings <span>on the prophet</span></h1>
            <h4 style="color:#fff">O you who believe! send your blessings on him.and salute him with all respect.</h4>
            <!-- <div class="btn-row"><a href="#" class="btn-style-1">read more</a></div> -->
          </div>
        </div>
        <img class="bannerimg" src="<?php echo base_url(); ?>assets/images/s1.png" alt="banner"> </div>
        
    </div>
  </div>
  <div class="container-fluid donown">
      <div class="col-md-3 col-sm-4 fstsectiond">
          <p class="fsecptga"> <span class="fsecspntag">Quick</span> Donation</p>
      </div>
      <div class="col-md-5 col-sm-6 commomdiv">
          <div class="row minputsec">
                <div class="col-md-3 col-sm-3">
                  <input type="radio" id="male" name="gender"  value="male" selected>
                <label class="comrdio" for="male">&#163;50</label>
              </div>
              <div class="col-md-3 col-sm-3">
                  <input type="radio" id="male1" name="gender" value="male">
                <label class="comrdio" for="male1">&#163;100</label>
              </div>
              <div class="col-md-3 col-sm-3">
                  <input type="radio" id="male2" name="gender" value="male">
                <label class="comrdio" for="male2">&#163;150</label>
              </div>
              <div class="col-md-3 col-sm-3">
                  <input type="radio" id="male3" name="gender" value="male">
                <label class="comrdio" for="male3">&#163;200</label>
              </div>
          </div>
          
      </div>
      <div class="col-md-4 col-sm-12 commomdiv">
          <button class="donatbutton" onclick="window.location.href='<?php echo base_url(); ?>donation'">Donate</button>
      </div>
  </div>
  <div class="container ownconta">
      <div class="row">
        <div class="col-md-12 col-sm-12">
            <h2 class="toptitle">THE HOUNSLOW OUTREACH PROJECT IS A DAWAH BRANCH OF HOUNSLOW JAMIA MASJID, DEDICATED TO SPREADING KNOWLEDGE ABOUT ISLAM, REACHING MILLIONS OF MUSLIMS & NON-MUSLIMS WORLDWIDE, THROUGH THE MEDIA AND PROGRAMMES</h2>
        </div>
        <div class="col-md-12 col-sm-12 mainboxda mobilemainbox">
          <div class="col-md-9 col-sm-12">
              <h2>SPONSORING DOMESTIC OUTREACH</h2>
              <hr class="hrdawa">
              <p class="titleda">Our domestic projects have been established for the best part of 20 years. These include feeding the homeless and needy, aiding children with disabilities, partnering with the police and faith groups in tackling extremism, creating a Muslim presence in the local political arena, visit my Mosque programmes, interfaith dialogues and iftar programmes and so much more.</p>
              <p>All this has led to us becoming an established presence in one of the most thriving cities in the world. Help us reach even more people and continue to benefot thousands.</p>
             <button class="donatbutton" onclick="window.location.href='<?php echo base_url(); ?>donation'">Donate</button>
          </div>
          <div class="col-md-3 col-sm-12 imgdd">
              <img class="dawhimg" src="<?php echo base_url(); ?>assets/images/pro3.jpeg" />
          </div>
      </div>
      <div class="col-md-12 col-sm-12 mainboxda">
          <div class="col-md-3 col-sm-12 imgdd">
              <img class="dawhimg" src="<?php echo base_url(); ?>assets/images/pro2.jpeg" />
          </div>
          <div class="col-md-9 col-sm-12">
              <h2>SPONSORING RELIGIOUS PROGRAMMING</h2>
              <hr class="hrdawa" style="border-top: 3px solid #3bc675;">
              <p class="titleda">By the Grace of Allah, we have been honoured to host many distinguished personalities of different nationalities and in different languages over the last 20 years. Our courses, retreats and discourses have lived in the hearts of thousands.</p>
              <p>We have also been broadcasting live speeches since 2015, transmitting knowledge about Islam to  people all over the world.<br>
Sponsoring and arranging for such programmes requires the support of the community. Help us continue and enhance our efforts to spread the message of Islam.
</p>
              <!--<a href="https://www.thedawahproject.com/sponsoring-religious-programming/" class="linkda">SEE MORE</a>-->
              <button class="donatbutton" onclick="window.location.href='<?php echo base_url(); ?>donation'">Donate</button>
          </div>
      </div>
       <div class="col-md-12 col-sm-12 mainboxda mobilemainbox">
          <div class="col-md-9 col-sm-12">
              <h2>INTERNATIONAL PROJECTS</h2>
              <hr class="hrdawa" style="border-top: 3px solid #f36d8e;">
              <p class="titleda">In countries where education and basic necessities are hard to come by, the Hounslow Outreach Project  has partnered with reliable and established organisations to spread the reliable information about Islam.</p>
              <p>Since 2010, the Hounslow Outreach Project has also helped with emergency appeals in Indonesia, Turkey, Pakistan, Yemen and other countries, helping with food, housing and clothing 
Bringing light to those who believe there is no hope has a tremendous reward. Help us grow our presence across the world.</p>
              <!--<a href="https://www.thedawahproject.com/supporting-radio-campaign-africa/" class="linkda">SEE MORE</a>-->
              <button class="donatbutton" onclick="window.location.href='<?php echo base_url(); ?>donation'">Donate</button>
          </div>
          <div class="col-md-3 col-sm-12 imgdd">
              <img class="dawhimg" src="<?php echo base_url(); ?>assets/images/pro1.jpeg" />
          </div>
      </div>   
      
      </div>
      
  </div>
  
    <?php include('footer.php'); ?>
    <script>
          var vid = document.getElementById("myVideo"); 
 // console.log(vid);
    vid.play(); 
    </script>