<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Divorce Service</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Divorce Service</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Divorce Service</a></h2>
                <p><b>Divorce Process – Hounslow Jamia Masjid</b>
</p><p>
Please also note the Masjid is not providing a form of divorce initiated by the wife, which is effected by the return of her husband's wedding gift. This is known as Khula. We cater for Talaq, the divorce pronounced by the husband. For this to take place, both parties have to be in agreement and be physically present.
</p><p>
1. All new and prospective clients, must download the Divorce Booking Form, fill it in and post (addressed to Hounslow Jamia Masjid & Islamic Centre, 367 Wellington Road South, TW4 5HU) or E-Mail to the Masjid (info@hounslowmasjid.co.uk).
</p><p>
2. Upon obtaining a fully completed booking form with the relevant details from the applicant – the Masjid will register the application.
</p><p>
*Please note the average processing time from receipt of booking form to completion is approximately 4 weeks. During this time both parties will be contacted with a view to reconciliation.The fee due at time of application is £100*
</p><p>
3. The Masjid will ensure the Mahr (dowry) agreed at the time of marriage has been paid in full. The Masjid will only consider the full amount of dower to have been paid by the husband, where this amount is identical to the full dower amount, as originally specified at the time of marriage.
</p><p>
4. The Masjid will also ensure that 3 months expenditure will covered by the husband. The finer details and arrangements surrounding this will be subject to discussion and agreement.
</p><p>
5. After all of the above stages have been reached, the Masjid will issue two original copies of Islamic divorce; one will be sent, with the dower amount, by post to the woman, and one copy will be presented or forwarded to the applicant.
</p><p>
An application will not be registered if any details or documents mentioned below are not presented on the day of meeting:
</p><p>
  <ol>
    <li>Nikah Na’ama / Wedding Certificate</li>
    <li>Passport of each party</li>
    <li>Proof of address of husband</li>
  </ol>
  <ul>
    <li><b>The Masjid conducts Islamic divorces only</b></li>
    <li><b>It does not conduct cases as part of the UK legal or judicial systems</b></li>
    <li><b>For advice regarding a civil divorce, please consult a qualified, legal representative.</b></li>
  </ul>
</p><p>
Please find the Divorce Booking Form below (reference to points 1 and 2 above)
</p><p>

<a href="<?php echo base_url(); ?>assets/upload/HJM_Divorce_Booking_Form.docx" class="atagclass">HJM_Divorce_Booking_Form.docx</a>
                
              </div>
            </div>

            <div class="contact-form">
              <form action="<?= site_url('welcome/divorceform'); ?>" method="post" id="registervalidation" enctype="multipart/form-data">
                  <h3>Husband Details</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="nameh" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snameh" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" pattern=".{5,}" name="phoneh" placeholder="Your Contact">
                    </div>
                    <div class="col-md-6">
                      <input required type="date" name="bodh" max="<?= date('Y-m-d') ?>" placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressh" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-12">
                      <textarea name="overseash" required cols="6" rows="6" placeholder="Your Overseas"></textarea>
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">UK Resident?</p>
                      <input type="radio" id="male" name="hukr" value="yes" required>
                      <label for="male" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="no" name="hukr" value="no">
                      <label for="no" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="natih" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passph" placeholder="Your Passport Number">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">Born Muslim?</p>
                      <input type="radio" id="byes" name="bornh" value="yes" required>
                      <label for="byes" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="bno" name="bornh" value="no">
                      <label for="bno" style="margin: 0 6px;">No</label><br>
                    </div>
                  </div>
                  <!-- wife data -->
                    <h3 style="    margin-top: 15px;">Wife Details</h3>
                    <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fnamew" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snamew" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" pattern=".{5,}" name="phonew" placeholder="Your Contact">
                    </div>
                    <div class="col-md-6">
                      <input required type="date" name="bodw" max="<?= date('Y-m-d') ?>"  placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressw" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-12">
                      <textarea name="overseasw" required cols="6" rows="6" placeholder="Your Overseas"></textarea>
                    </div>
                    <div class="col-md-12" style="display: inline-flex; margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">UK Resident?</p>
                      <input type="radio" id="malew" name="wukr" value="yes" required>
                      <label for="malew" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="now" name="wukr" value="no">
                      <label for="now" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="natiw" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passpw" placeholder="Your Passport Number">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">Born Muslim?</p>
                      <input type="radio" id="byesw" name="bornw" value="yes" required>
                      <label for="byesw" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="bnowq" name="bornw" value="no">
                      <label for="bnowq" style="margin: 0 6px;">No</label><br>
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Islamic Marriage Certificate (Nikah) Details</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" pattern="[a-zA-Z ]+" name="fullnamemos" placeholder="Full Name of Mosque / Centre">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="certifinumber" placeholder="Certificate Number">
                    </div>
                    <div class="col-md-6">
                      <input required type="date" name="contactdate" placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <input required type="text" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" name="email" placeholder="Your Email ID">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Names of Two Muslim Male Witnesses</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wname1" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wnation1" placeholder="1st Witness Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wname2" placeholder="2nd Witness Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wnation2" placeholder="2nd Witness Nationality">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Supporting Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Islamic Marriage Certificate</p>
                      <input required type="file" name="mrrcertif" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Husband’s Passport</p>
                      <input required type="file" name="husbenapss" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Wife’s Passport</p>
                      <input required type="file" name="wifepassport" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Witness 1 Passport</p>
                      <input required type="file" name="w1passpoet" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Witness 2 Passport</p>
                      <input required type="file" name="w2passpoet" placeholder="1st Witness Name">
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-md-6">
                      <input required type="number" name="price" placeholder="Your Price">
                    </div>
                    <div class="col-md-6">
                      <select class="give-input" name="paymode" required>
                      <option value="">Selecct Payment </option>
                      <option value="stripe">Card</option>
                      <option value="Paypal">Paypal</option>
                    </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                      <input type="submit" value="Submit">
                    </div>
                </form>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.js"></script>
<script type="text/javascript">
    $(function () {
        $('#registervalidation').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                mrrcertif: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Proof of Islamic Marriage Certificate'
                        }
                    }
                },
                husbenapss: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Husband’s Passport'
                        }
                    }
                },
                wifepassport: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Wife’s Passport'
                        }
                    }
                },
                w1passpoet: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Witness 1 Passport'
                        }
                    }
                },  
                w2passpoet: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Witness 2 Passport'
                        }
                    }
                },
                hukr: {
                    validators: {
                        notEmpty: {
                            message: 'Please Select Above option'
                        }
                    }
                },
                bornh: {
                    validators: {
                        notEmpty: {
                            message: 'Please Select Above option'
                        }
                    }
                },
                              
            }
        });

    });
  </script>