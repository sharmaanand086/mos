<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>New Muslims</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">New Muslims</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
               <div class="frame"> 
                <img src="<?php echo base_url(); ?>assets/images/website/NewMuslimSupport.jpg" alt="img">
              </div>
              <div class="text-box">
                <h2><a>New Muslims</a></h2>
                <p>As more people find out about Islam, some decide to convert. Hounslow Jamia Masjid provides advice, support and friendship. Hounslow Jamia Masjid has trained Imams to provide religious guidance and advice on day-to-day matters affecting the community such as bereavement, cultural challenges, family issues and matrimonial problems.
</p><p>
Weekly sessions are also provided so that they can learn to pray, read the Qur‘an and perform the other duties that Muslims are required to carry out.
</p><p>
Regular programmes include Fiqh (rules and regulations) and Tafsir (explanation) of the Qur‘an in English, Urdu, Arabic.
</p><p>
In Islam, Mosques are a focal point for the local Muslim community in religious and social matters.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
