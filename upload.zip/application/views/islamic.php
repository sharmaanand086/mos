<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Islamic Will Services</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Islamic Will Services</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box" style="margin-bottom: 1%;">
              <div class="text-box">
                <h2><a>Islamic Will Services</a></h2>
                <p>Our Islamic Will Writing and Islamic Wills are Shariah Compliant for your peace of mind </p><p>
Even if you have no money or property, but have children under the age of 18 years, you must make an Islamic Will. If both parents have died, leaving behind children under 18 years, the custody of the children will not necessarily automatically go to family members. This can be a lengthy process, but if you have written a Sharia compliant Will and nominated guardians, you can be sure that your children are looked after by the people you have chosen. 
</p><p>An Islamic Will is a straightforward and inexpensive document to arrange. However, very few people in the Muslim population have taken this important step, and according to Sharia, one of the most important duties in a Muslim person’s life is to write an Islamic Will. Our Shariah compliant Islamic Will writing specialists ensure that your requirements are documented according to Shariah law. 
</p><p>Our specialist practitioners provide a bespoke service and are able to meet you to make the process easier for you. 
</p><p>Fill out the contact form below and we will be in touch within 24 hours to discuss further</p>
              </div>
            </div>
            <!--EVENT POST END--> 
           <div class="contact-form">
                
                <form action="<?= site_url('welcome/submitislam'); ?>" id="registervalidation" method="post" enctype="multipart/form-data">
                <!--<h3></h3>-->
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="first" placeholder="Your Full Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" type="text" name="email" placeholder="Your Email ID">
                    </div>
                    <div class="col-md-6">
                      <input required pattern=".{5,}" type="text" name="give_last" placeholder="Your Phone Number">
                    </div>
                    
                    <div class="col-md-12">
                      <textarea name="give_last1" required cols="6" rows="6" placeholder="Ask Question"></textarea>
                    </div>
                    
                  </div>
                  
                  <input class="give-submit give-btn" id="give-purchase-button" name="give-purchase" value="Submit" type="submit" style="float:left;">
                </form>
              </div>
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  <!--Footer-->
  
  <?php include('footer.php'); ?>
<script type="text/javascript">
    $( "input[name='give-radio-donation-level']" ).change(function() {
          var a = $(this).val();
          $('#aaa').html(a);
          $('#give-amount-text').html(a);
});
  </script>