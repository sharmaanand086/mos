<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>interfaith</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Interfaith</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>interfaith</a></h2>
                <p>We believe in promoting mutual respect and understanding between Muslims and people of other faiths throughout the UK and Europe. It is here also very important always to help Non-Muslim communities and organizations to understand that Islam as a peaceful religion and that we are as Muslims open to dialogue on all matters regarding faith.
</p><p>
The Interfaith activities at the mosque includes facilitating group visits, consultation with statutory bodies and lectures and conferences on Islam in the Masjid and other faith establishments. We have held annual community Iftar events and actively participate in the Visit My Mosque events which sees non-Muslims experience the Mosque.
</p><p>
Hounslow Jamia Masjid's active involvement with local and county wide interfaith based groups, councils and forums has provided a strong foundation for the goals of such interfaith activities to yield productive outcomes.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
