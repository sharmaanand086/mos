<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Islamic Divorce Booking Form</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li class="active">Islamic Divorce Booking Form</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--Contact-->
    <section class="contact-section">
      <div class="container">
        <div class="contact-row">
          <div class="row">
            <div class="col-md-12 col-sm-9">
              <div class="contact-form">
                
                <form action="<?= site_url('welcome/form'); ?>" method="post">
                  <h3>Husband Details</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fnameh" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snameh" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phoneh" placeholder="Your Contact">
                    </div>
                    <div class="col-md-6">
                      <input required type="Date" name="bodh" placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressh" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-12">
                      <textarea name="overseash" required cols="6" rows="6" placeholder="Your Overseas"></textarea>
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">UK Resident?</p>
                      <input type="radio" id="male" name="hukr" value="yes">
                      <label for="male" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="no" name="hukr" value="no">
                      <label for="no" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="natih" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passph" placeholder="Your Passport Number">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">Born Muslim?</p>
                      <input type="radio" id="byes" name="bornh" value="yes">
                      <label for="byes" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="bno" name="bornh" value="no">
                      <label for="bno" style="margin: 0 6px;">No</label><br>
                    </div>
                  </div>
                    <!-- wife data -->
                    <h3 style="    margin-top: 15px;">Wife Details</h3>
                    <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fnamew" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snamew" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phonew" placeholder="Your Contact">
                    </div>
                    <div class="col-md-6">
                      <input required type="Date" name="bodw" placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressw" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-12">
                      <textarea name="overseasw" required cols="6" rows="6" placeholder="Your Overseas"></textarea>
                    </div>
                    <div class="col-md-12" style="display: inline-flex; margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">UK Resident?</p>
                      <input type="radio" id="malew" name="wukr" value="yes">
                      <label for="malew" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="now" name="wukr" value="no">
                      <label for="now" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="natiw" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passpw" placeholder="Your Passport Number">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;">Born Muslim?</p>
                      <input type="radio" id="byesw" name="bornw" value="yes">
                      <label for="byesw" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="bnowq" name="bornw" value="no">
                      <label for="bnowq" style="margin: 0 6px;">No</label><br>
                    </div>
                  </div>
                   <h3 style="margin-top: 15px;">Islamic Marriage Certificate (Nikah) Details</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" name="natiw" placeholder="Full Name of Mosque / Centre">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passpw" placeholder="Certificate Number">
                    </div>
                    <div class="col-md-6">
                      <input required type="Date" name="bodw" placeholder="Your Contact">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Names of Two Muslim Male Witnesses</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required type="text" name="natiw" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passpw" placeholder="1st Witness Nationality">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="natiw" placeholder="2nd Witness Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="passpw" placeholder="2nd Witness Nationality">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Supporting Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Islamic Marriage Certificate</p>
                      <input required type="file" name="natiw" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Husband’s Passport</p>
                      <input required type="file" name="natiw" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Wife’s Passport</p>
                      <input required type="file" name="natiw" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Witness 1 Passport</p>
                      <input required type="file" name="natiw" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Witness 2 Passport</p>
                      <input required type="file" name="natiw" placeholder="1st Witness Name">
                    </div>
                  </div>
                    <div class="col-md-12">
                      <input type="submit" value="Submit">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Contact--> 
  </div>
  
  <?php include('footer.php'); ?>
