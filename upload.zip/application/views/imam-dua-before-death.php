<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Imam Dua Before Death</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Imam Dua Before Death</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Imam Dua Before Death</a></h2>
                <p>Call on our services at the critical time when your loved one is about to leave this world (in situations when it is possible to know the final moments) Message 07506038393 to arrange the Imam to attend for a Dua and reminder</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
