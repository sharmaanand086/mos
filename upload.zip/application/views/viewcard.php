<?php include('header.php'); ?>
  <script src="https://js.stripe.com/v3/"></script>

<div id="inner-banner" style="    padding: 67px;">
   
  </div>

<div id="main"> 
    <!--DONATION SECTION START-->
    <section class="donation-section" style="background:#00000073">
      <div class="container">
        <div id="give-form-370-wrap" class="give-form-wrap give-display-onpage">
          <h2 class="give-form-title">Payment</h2>
          <form id="payment-form" method="post" class="give-form give-form-370 give-form-type-multi" action="<?= site_url('welcome/getpayment'); ?>">
            <input name="give-price-id" value="0" type="hidden">
            <div id="give_purchase_form_wrap">
              <fieldset id="give_checkout_user_info">
                <legend>Card Info</legend>
                <p id="give-first-name-wrap" class="form-row form-row-first form-row-responsive">
                  <div id="card-element">
                    <!-- A Stripe Element will be inserted here. -->
                  </div>
                  <div id="card-errors" role="alert" style="color: red"></div>
                </p>
              </fieldset>
              <fieldset id="give_purchase_submit">
                <p id="give-final-total-wrap" class="form-wrap "> <span class="give-donation-total-label">Donation Total:</span> <span class="give-final-total-amount" data-total="50">&#163;<span id="aaa"><?= $alldata[0]->amount; ?></span></span> </p>
                <input name="give_action" value="purchase" type="hidden">
                <input name="give-gateway" value="paypal" type="hidden">
                <input name="name" value="<?= $alldata[0]->name; ?>" type="hidden">
                <input name="email" value="<?= $alldata[0]->email; ?>" type="hidden">
                <input name="price" value="<?= $alldata[0]->amount; ?>" type="hidden">
                <input name="id" value="<?= $id; ?>" type="hidden">
                <div class="give-submit-button-wrap give-clearfix">
                  <input class="give-submit give-btn" id="give-purchase-button" name="give-purchase" value="Donate Now" type="submit">
                  <span class="give-loading-animation"></span> </div>
              </fieldset>
            </div>
          </form>
        </div>
      </div>
    </section>
    <!--DONATION SECTION  END--> 
  </div>
  
<?php include('footer.php'); ?>
<script type="text/javascript">
  // Create a Stripe client.
var stripe = Stripe('pk_test_fTzP4zV0u7P7I5PXRldKMAgk');

// Create an instance of Elements.
var elements = stripe.elements();

// Custom styling can be passed to options when creating an Element.
// (Note that this demo uses a wider set of styles than the guide below.)
var style = {
  base: {
    color: '#32325d',
    fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
    fontSmoothing: 'antialiased',
    fontSize: '16px',
    '::placeholder': {
      color: '#aab7c4'
    }
  },
  invalid: {
    color: '#fa755a',
    iconColor: '#fa755a'
  }
};

// Create an instance of the card Element.
var card = elements.create('card', {style: style});

// Add an instance of the card Element into the `card-element` <div>.
card.mount('#card-element');

// Handle real-time validation errors from the card Element.
card.on('change', function(event) {
  var displayError = document.getElementById('card-errors');
  if (event.error) {
    displayError.textContent = event.error.message;
  } else {
    displayError.textContent = '';
  }
});

// Handle form submission.
var form = document.getElementById('payment-form');
form.addEventListener('submit', function(event) {
  event.preventDefault();

  stripe.createToken(card).then(function(result) {
    if (result.error) {
      // Inform the user if there was an error.
      var errorElement = document.getElementById('card-errors');
      errorElement.textContent = result.error.message;
    } else {
      // Send the token to your server.
      stripeTokenHandler(result.token);
    }
  });
});

// Submit the form with the token ID.
function stripeTokenHandler(token) {
  // Insert the token ID into the form so it gets submitted to the server
  var form = document.getElementById('payment-form');
  var hiddenInput = document.createElement('input');
  hiddenInput.setAttribute('type', 'hidden');
  hiddenInput.setAttribute('name', 'stripeToken');
  hiddenInput.setAttribute('value', token.id);
  form.appendChild(hiddenInput);

  // Submit the form
  form.submit();
}
</script>
