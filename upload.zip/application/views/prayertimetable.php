<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Pray Time Table</h1>
      
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-8">
              <p>January, 2021<br>
Islamic Month: 21 Jumaad-Al-Awwal 1442</p>
            </div>
            <div class="col-md-3 col-sm-4">
                <select name="cars" id="cars" style="width: 80%;float: right;">
                  <?php foreach($month as $row): ?>
                    <option value="<?= $row->month ?>" <?= ($row->month == $urlvalue?'Selected':'') ?>><?= $row->month ?></option>
                  <?php endforeach; ?>
                </select>
            </div>
          <div class="col-md-12 col-sm-12"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box" style="    overflow: auto;">
                <table cellspacing="1" cellpadding="4" border="0" id="ctl00_ContentPlaceHolder1_GridView1" style="background-color:#99C5DF;border-color:#99C5DF;border-width:0px;width:100%;">
    <tbody><tr align="center" style="color:White;background-color:#003471;font-size:12px;">
      <th scope="col">Date</th><th scope="col">Prayer Day</th><th scope="col">Hijriy Day</th><th scope="col">Fajr Start</th><th scope="col">Fajr Jamaat</th><th scope="col">Sun Rise</th><th scope="col">Zuhr Start</th><th scope="col">Zhur Jamaat</th><th scope="col">Asr Start</th><th scope="col">Asr Jamaat</th><th scope="col">Maghrib Start</th><th scope="col">Maghrib Jamaat</th><th scope="col">Isha Start</th><th scope="col">Isha Jamaat</th>
    </tr>
<?php foreach($data as $datas): ?>
    <tr style="<?= ($datas->month == $curentm && $datas->date == $currentd?'background-color: #addce4':'background-color:#C9EBFF') ?>">
      <td style="height:7px;width:5px;">
          <span><?= $datas->date ?></span>                
      </td>
      <td style="height:7px;width:20px;">
          <span><?= $datas->prayerdate ?></span>
      </td>
      <td align="center" style="height:7px;width:10px;">
          <span><?= $datas->hijriyday ?></span>
      </td>
      <td align="center">
              <?= $datas->FajrStart ?>
      </td>
      <td align="center">
              <?= $datas->FajrJamaat ?>
      </td>
      <td align="center">
              <?= $datas->SunRise ?>
      </td>
      <td align="center">
              <?= $datas->ZuhrStart ?>
      </td>
      <td align="center">
              <?= $datas->ZhurJamaat ?>
      </td>
      <td align="center">
              <?= $datas->AsrStart ?>
      </td>
      <td align="center">
              <?= $datas->AsrJamaat ?>
      </td>
      <td align="center">
              <?= $datas->MaghribStart ?>
      </td>
      <td align="center">
              <?= $datas->MaghribJamaat ?>
      </td>
      <td align="center">
              <?= $datas->IshaStart ?>
      </td>
      <td align="center">
              <?= $datas->IshaJamaat ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  </table>
              </div>
            </div>
            <!--EVENT POST END--> 
          </div>
        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
