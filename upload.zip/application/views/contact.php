<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Contact Us</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li class="active">Contact Us</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--Contact-->
    <section class="contact-section">
      <div class="container">
        
        <div class="contact-row">
          <div class="row">
            <div class="col-md-5 col-sm-6">
              <div class="contact-box">
                <h3>Contact Information:</h3>
                <ul>
                  <li> <img src="assets/images/contact-icon-1.png" alt="img">
                    <div class="holder">
                      <p>367 Wellington Road South Hounslow, TW4 5HU United Kingdom</p>
                    </div>
                  </li>
                  <li> <img src="assets/images/contact-icon-2.png" alt="img">
                    <div class="holder">
                      <p>020 8570 0938</p>
                      <p>(+44) 20 8570 0938</p>
                    </div>
                  </li>
                  <li> <img src="assets/images/contact-icon-3.png" alt="img">
                    <div class="holder">
                      <p><a href="mailto:">admin@hounslowmasjid.co.uk</a></p>
                    </div>
                  </li>
                </ul>
                <!-- <div class="text-col">
                  <p>This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin.</p>
                </div> -->
              </div>
            </div>
            <div class="col-md-7 col-sm-6">
              <div class="contact-form">
                <h3>Contact Us</h3>
                <form action="<?= site_url('welcome/form'); ?>" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="name" placeholder="Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phone" placeholder="Your Contact">
                    </div>
                    <div class="col-md-12">
                      <input required name="email" type="text" placeholder="Your Email">
                    </div>
                    <!--<div class="col-md-6">-->
                    <!--  <select name="subject">-->
                    <!--    <option>Select Subject</option>-->
                    <!--    <option>Select one</option>-->
                    <!--    <option>Select two</option>-->
                    <!--  </select>-->
                    <!--</div>-->
                    <div class="col-md-12">
                      <textarea name="message" required cols="10" rows="10" placeholder="Comments"></textarea>
                    </div>
                    <div class="col-md-12">
                      <input type="submit" value="Contact Us">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Contact--> 
  </div>
  
  <?php include('footer.php'); ?>
