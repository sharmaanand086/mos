<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>News</h1>
      <ol class="breadcrumb">
        <li><a href="index.php">Home</a></li>
        <li><a>Education</a></li>
        <li><a >Education</a></li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-9 col-sm-8"> 
            <?php 
            //var_dump($newes);
            foreach($newes as $row):
            ?>
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="frame" style="width: 20%;margin-right: 5%;"><a><img src="<?= $row->image ?>" alt="img"></a></div>
              <div class="text-box" style="width: 70%;">
                <h2><a href="#"><?= $row->title ?></a></h2>
                <div class="post-meta">
                  <ul>
                    <li><a><i class="fa fa-calendar" aria-hidden="true"></i><?= date_format(date_create($row->post_date),"d F Y") ?></a></li>
                  </ul>
                </div>
                <p><?= $row->short_desc ?></p>
                <a href="<?php echo base_url(); ?>news/<?= $row->id ?>/<?= str_replace(" ","-",$row->title) ?> " class="read-post">Read Post</a> </div>
            </div>
          <?php endforeach; ?>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
