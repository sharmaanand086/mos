  <!--Footer-->
  <footer id="footer" style="background: url(<?php echo base_url(); ?>assets/images/s1.png) no-repeat left top/cover;">
    <section class="footer-section-1">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">
            <div class="footer-box"> <a href="index.html" class="footer-logo"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo"></a>
              <h5 style="color: #fff;">SERVING THE COMMUNITY, WORKING IN PARTNERSHIP</h5>
              <p>Hounslow Jamia Masjid & Islamic Centre is the largest purpose built mosque in West London. We believe that our primary role is to serve the needs of the local community and to work towards the common good.
<br>
Our strong partnerships with the London Borough of Hounslow Council, Hounslow Primary Care Trust, the Metropolitan Police, other faith groups and many others have helped us to contribute towards improvements within the local community. This builds on the very essence of our Mosque: a coming together of distinguished Muslims and non-Muslims to create a cohesive and tolerant society.</p>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="footer-box">
              <h3>Latest News</h3>
              <div class="latest-news-widget twitterclass" style="height: 450px;overflow: auto;">
               <a class="twitter-timeline" href="https://twitter.com/hounslowjmasjid?ref_src=twsrc%5Etfw" data-tweet-limit="3">Tweets by hounslowjmasjid</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="footer-box">
              <h3>FOLLOW US ON FACEBOOK</h3>
              <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FHounslowJamiaMasjid%3Fref%3Dhl&amp;width=330&amp;height=450&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=true&amp;show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:330px; height:450px;" allowtransparency="true"></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="footer-section-2">
      <div class="container"> <strong class="copyright">&copy; <?= date('Y'); ?>. HOUNSLOW JAMIA MASJID AND ISLAMIC CENTRE. WEBSITE DESIGNED BY <a class="companymade" style="color: #ffad05;" href="http://hashthattags.com/">HashThatTags</a></strong>
        <div class="footer-social">
          <ul>
            <li><a href="http://www.facebook.com/HounslowJamiaMasjid"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="http://twitter.com/hounslowjmasjid"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="http://www.youtube.com/hounslowjamiamasjid"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
          </ul>
        </div>
      </div>
    </section>
  </footer>
  <!--Footer--> 
</div>
<!--JQUERY START--> 
<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script> 
<!--BOOTSTRAP JS--> 
<script src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcavdONRtu_0BfV63xiQX1LiJpX1ZJ2N0" type="text/javascript"></script>
<!--EVENT TIMER JS--> 
<script src="<?php echo base_url(); ?>assets/js/jquery_countdown.js"></script> 
<!---Modernizr Script--> 
<script src="<?php echo base_url(); ?>assets/js/modernizr.custom.js"></script> 
<!---Search Script--> 
<script src="<?php echo base_url(); ?>assets/js/search-script.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.bxslider.min.js"></script> 
<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script> 
<script src="<?php echo base_url(); ?>assets/js/jquery.prettyPhoto.js"></script> 
<!--CUSTOM JS START--> 
<script src="<?php echo base_url(); ?>assets/js/custom_script.js"></script>
<script type="text/javascript">


  $("#cars").change(function () {
        var end = this.value;
        window.location.href="<?php echo base_url(); ?>prayertimetable/"+end;
    });
  $('#subscribe').click(function(e){
        e.preventDefault();
        var n=$('#name').val();
        var e=$('#email').val();
        var p=$('#phone').val();
        console.log(n);
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(n==null || n=="" ||e==null || e=="" ||p==null || p=="")
        {
          alert('Name , Email Id or Contact No field cannot be empty');
          return false;
        }
          if (!filter.test(e))
        {
          alert('Please enter a valid Email Id');
          return false;
        }

        $.ajax({
               "url": "<?php echo site_url('welcome/subscribe')?>",
               "type": "POST",
               data: {name:n,email:e,phone:p},
               dataType: "text",  
                cache:false,
             complete: function (response) {
              
            },
            success :  function (result) {
              if(result == 1){
                $('#succmsg').fadeIn(3000);
                $('#succmsg').fadeOut(3000);
              }else{
                alert('Somthing Went Wrong!!')
              }
            },
            error: function () {
               
            },
        });
        return false;
  
    })

                    

</script>
</body>
</html>