<?php include('header.php'); ?>
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1><?= $events[0]->title ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>events">News</a></li>
        <li class="active"><?= $events[0]->title ?></li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a><?= $events[0]->title ?></a></h2>
                <p><?= nl2br($events[0]->long_desc); ?></p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
