<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>FACILITIES</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">SERVICES</a></li>
        <li class="active">FACILITIES</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>FACILITIES</a></h2>
                <p>Our Mosque has the following facilities available for its worshippers:</p><p>
<ol><li>
Main prayer hall with a capacity for up to 1500 worshippers.</li><li>
Upper prayer hall and lecture room. Capacity for 500 worshippers.</li><li>
Library with a large selection of books in English, Arabic and Urdu.</li><li>
Fully equipped catering kitchen for functions.</li><li>
Management office, storage rooms</li><li>
Secure car park for 150 cars, including allocated disabled parking space.</li><li>
Centralised wudhu area for men and women including disabled toilet access facilities with a capacity of up to 40 people at peak times.</li><li>
Extension currently ongoing to develop an Islamic and cultural centre equipped with a number of existing teaching, meeting and seminar rooms available with further plans to develop a gym and cafeteria.</li><li>
Residential lodging located inside the mosque to accommodate the local imam.</li>

</ol>
</p><p>
If you would like to book the community hall, please complete the below form and email to info@hounslowmasjid.co.uk
</p><p>
By completing the form you agree to the terms of hire document also.

 </p><p>
<a href="<?php echo base_url(); ?>/assets/upload/Agreement_Form_for_Hire_of_Facilities_Version_2.docx" class="atagclass">Agreement form for Hire of Facilities</a>
</p><p>
<a href="<?php echo base_url(); ?>/assets/upload/Booking_Policy_and_Prices_2019.docx" class="atagclass">Booking_Policy_and_Prices_2019.docx</a>

 
</p><p>
Our new function hall is also available for hire from £500. Please visit us and check out this wonderful facility ideal for weddings and other functions</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
