<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Download</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo  base_url(); ?>">Home</a></li>
        <li><a>Resources</a></li>
        <li class="active">Download</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Download</a></h2>
                <p>Please click on the links belove to download a PDF files on this page.</p>
              </div>
              <?php 
              //var_dump($authors);
              ?>
              <?php foreach ($authors as $value) {
              ?>
              <div class="text-box extrabox">
                <div class="img-box"><img src="<?php echo base_url() ?>assets/images/pdf.png" alt="img"></div>
                <div class="main-box" style="<?php echo ($value->desci != ""?"":"") ?>">
                  <p class="title-download"><a href="<?php echo base_url() ?>assets/download/<?= $value->link ?>"class="atagclass"><?= $value->name ?></a> </p>
                  <?php if($value->desci != ""){ ?>
                  <p class="desc-download"><?= $value->desci ?></p>
                <?php } ?>
                </div>
              </div>

            <?php  } ?>
            </div>
            <!--EVENT POST END--> 
             <div class="pagination-col">
          <nav aria-label="Page navigation">
            <ul class="pagination">
              <?php echo $links; ?>
            </ul>
          </nav>
        </div>
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
