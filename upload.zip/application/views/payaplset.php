<?php
session_start();
    $rootPath = "";
    include_once('Config.php');
    include_once('Sample.php');
// var_dump($alldata);
?>


<div id="inner-banner" style="    padding: 67px;">
   
  </div>

<div id="main"> 
    <!--DONATION SECTION START-->
    <section class="donation-section" style="background:#00000073">
      <div class="container">
        <div id="give-form-370-wrap" class="give-form-wrap give-display-onpage">
          <h2 class="give-form-title">Pay By Paypal</h2>
          <form id="payment-form" method="post" class="give-form give-form-370 give-form-type-multi" action="<?= site_url('welcome/getstripepayment'); ?>">
            <input name="give-price-id" value="0" type="hidden">
            <div id="give_purchase_form_wrap">
              <!--<fieldset id="give_checkout_user_info">-->
              <!--  <legend>Card Info</legend>-->
              <!--  <p id="give-first-name-wrap" class="form-row form-row-first form-row-responsive">-->
              <!--    <div id="card-element">-->
                    <!-- A Stripe Element will be inserted here. -->
              <!--    </div>-->
              <!--    <div id="card-errors" role="alert" style="color: red"></div>-->
              <!--  </p>-->
              <!--</fieldset>-->
              <fieldset id="give_purchase_submit">
                
                <input name="give_action" value="<?= $cond; ?>" type="hidden">
                <input name="give-gateway" value="paypal" type="hidden">
                <input name="email" value="<?= $alldata[0]->email; ?>" type="hidden">
                <input name="price" value="<?= $alldata[0]->deposite; ?>" type="hidden">
                <input type="hidden" name="camera_amount" id="camera_amount" value="200">
            	<input type="hidden" name="tax_amt" id="tax_amt" value="0">
            	<input type="hidden" name="handling_fee" id="handling_fee" value="0">
            	<input type="hidden" name="insurance_fee" id="insurance_fee" value="0">
            	<input type="hidden" name="shipping_amt" id="shipping_amt" value="0">
            	<input type="hidden" name="shipping_discount" id="shipping_discount" value="0">
            	<input type="hidden" name="total_amt" id="total_amt" value="200">
            	<input type="hidden" name="currency_Code" id="currency_Code" value="USD">
                <input name="id" value="<?= $id; ?>" type="hidden">
                <div class="give-submit-button-wrap give-clearfix">
                    <p id="give-final-total-wrap" class="form-wrap " style="width: 100%;text-align: center"> <span class="give-donation-total-label" style="text-align: center;float: unset;">Total Payment:</span> <span class="give-final-total-amount" data-total="50">&#163;<span id="aaa"><?= $alldata[0]->deposite; ?></span></span> </p>
                    <div id="paypalCheckoutContainer" style="width: 50%;margin: auto;"></div>
                  <!--<input class="give-submit give-btn" id="give-purchase-button" name="give-purchase" value="Donation Now" type="submit">-->
                  <!--<span class="give-loading-animation"></span>-->
                  </div>
              </fieldset>
            </div>
          </form>
        </div>
      </div>
    </section>
    <!--DONATION SECTION  END--> 
  </div>
  <script src="https://www.paypal.com/sdk/js?client-id=sb&intent=capture&vault=false&commit=true<?php echo isset($_GET['buyer-country']) ? "&buyer-country=" . $_GET['buyer-country'] : "" ?>"></script>
<script type="text/javascript">

    paypal.Buttons({

        // Set your environment
        env: '<?= PAYPAL_ENVIRONMENT ?>',

        // Set style of buttons
        style: {
            layout: 'vertical',   // horizontal | vertical
            size:   'responsive',   // medium | large | responsive
            shape:  'pill',         // pill | rect
            color:  'gold',         // gold | blue | silver | black,
            fundingicons: false,    // true | false,
            tagline: false          // true | false,
        },

        // Wait for the PayPal button to be clicked
        createOrder: function() {
            let formData = new FormData();
            formData.append('item_amt', document.getElementById("camera_amount").value);
            formData.append('tax_amt', document.getElementById("tax_amt").value);
            formData.append('handling_fee', document.getElementById("handling_fee").value);
            formData.append('insurance_fee', document.getElementById("insurance_fee").value);
            formData.append('shipping_amt', document.getElementById("shipping_amt").value);
            formData.append('shipping_discount', document.getElementById("shipping_discount").value);
            formData.append('total_amt', document.getElementById("total_amt").value);
            formData.append('currency', document.getElementById("currency_Code").value);
            formData.append('return_url',  'http://hashthattags.com/mos/success.php' + '?commit=true');
            formData.append('cancel_url', 'http://hashthattags.com/mos/');

            return fetch(
                'createOrder.php',
                {
                    method: 'POST',
                    body: formData
                }
            ).then(function(response) {
                return response.json();
            }).then(function(resJson) {
                console.log('Order ID: '+ resJson.data.id);
                return resJson.data.id;
            });
        },

        // Wait for the payment to be authorized by the customer
        onApprove: function(data, actions) {
            return fetch(
                'getOrderDetails.php',
                {
                    method: 'GET'
                }
            ).then(function(res) {
            	console.log(res);
                return res.json();
            }).then(function(res) {
                //window.location.href = 'pages/success.php';
            });
        }

    }).render('#paypalCheckoutContainer');

</script>


