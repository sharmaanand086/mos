<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Sisters</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">Services</a></li>
        <li class="active">Sisters</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
               <div class="frame"> 
                <img src="<?php echo base_url(); ?>assets/images/website/Veil-articleLarge.jpg" alt="img">
              </div>
              <div class="text-box">
                <h2><a>Sisters</a></h2>
                <p>The status of women in society is neither a new issue nor is it a fully settled one. The issue of women in Islam is a topic of great misunderstanding and distortion due partly to a lack of understanding, but also partly due to misbehaviour of some Muslims which has been taken to represent the teachings of Islam.
</p><p>
There's no question that the Western media has played an important role in perpetuating these misconceptions. But in fairness, we should not blame the media alone. Western culture, in writings about other religions, in particular Islam, have distorted images. From books, novels, even in the academic circle, and sermons from the pulpit in places of worship, these kinds of prejudices are perpetuated.
</p><p>
Alhumdulillah the role of women in Hounslow Jamia Masjid is a pivotal one. From their financial contribution to the development of the Masjid, through to event organisation and support. We have regular religious classes and Gatherings of Praise and Remembrance. Coffee mornings, marriage events and more have all been held under the umbrella of the sisters team.</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
