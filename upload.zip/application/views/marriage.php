<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Marriage</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>services">SERVICES</a></li>
        <li class="active">Marriage</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box" style="border-bottom: 1px solid #00000063;">
              <div class="frame"> 
                <img src="<?php echo base_url(); ?>assets/images/website/27dc6b3e30d25fdd99e158b05b30d365.jpg" alt="img">
              </div>
              <div class="text-box">
                <h2><a>Marriage and Nikah Services</a></h2>
                <p>Family life is the building block of a successful society, and marriage is an occasion of great joy in the Muslim community. Hounslow Jamia Masjid facilitates the solemnisation of an Islamic contract of marriage. The newly-married couple are provided with an official 'Nikah' certificate to show they have been married according to Islamic Law.
</p><p>
The Nikah fee is currently £100 if carried out within the Masjid and £150 if carried out outside the Masjid.
</p><p>
We recommend that Nikah is booked at least 3 weeks prior to the planned date. Please also be aware that the summer months are a busy time for Nikah ceremonies so please book well in advance to avoid disappointment.
</p><p>
To book a Nikah please complete the booking form at the bottom and hand in to reception at: Hounslow Jamia Masjid & Islamic Centre, 367 Wellingrton Road South, TW4 5HU or email to info@hounslowmasjid.co.uk. Please also take your time to read through the Policy form before proceeding. For any immediate enquiries, you may contact the Imam on 07888 756028.
</p><p>
Documents and information required before Nikah:
</p><p>
  <ul><li>
    <b>Passport or Driving Licence</b> - we need your valid UK passport or UK driving licence as a photo ID
  </li><li>
    <b>Proof of Address</b> - we need your current utility bill or bank statement as a proof of address in the UK</li><li>
<b>Date of Nikah</b></li><li>
<b>Preferred Time</b> - Hounslow Jamia Masjid will do their utmost to meet preferred times, however, there will be occasions when this may not be possible.</li><li>
<b>Birth Certificates</b> - For the Bride and Bridegroom. If names have changed the Original copy of the Deed Poll.
<b>Divorcees</b> - Decree Absolute & Talak Documents in accordance with Islamic Sharia.</li><li>
<b>Widow/Widower</b> - Former spouses' death certificate.</li>
</ul>


</p><p>
**As of October 2017 we are now able to offer English civil marriages within the Mosque in addition to the Islamic Nikah. This is a huge step for the Mosque Alhumdulillah. Please speak to the Management and Imams for more details**
</p><p>
We are pleased to offer our Marriage service for Muslims of all ages and backgrounds. Clients find their ideal partner via the mosque's Marriage Bureau volunteers using a database of registered prospective partners and initiated meetings. Please visit:
</p><p>
<a href="http://www.muslimmarriageintro.co.uk/" class="atagclass">http://www.muslimmarriageintro.co.uk/</a>
</p><p>
***Due to COVID-19 we are not currently operating - normal service will resume as soon as situation improves***
</p><p>
Related forms:
</p><p>
<a href="<?php echo base_url(); ?>assets/upload/2020_Booking_form.docx" class="atagclass">2020_Booking_form.docx</a>
</p><p>
<a href="<?php echo base_url(); ?>assets/upload/Nikah_Policy_Form_2019v1.docx" class="atagclass">Nikah_Policy_Form_2019.docx</a></p>
                
              </div>
            </div>
            
            <!--EVENT POST END--> 
           <div class="contact-form">
                
                <form action="<?= site_url('welcome/nikahform'); ?>" id="registervalidation" method="post" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-md-6">
                      <h5 style="margin: 0 0 7px 0;">Date of Nikah</h5>
                      <input required type="date" min="<?= date('Y-m-d') ?>" name="nikahdate" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <h5 style="    margin: 0 0 7px 0;">Time of Nikah</h5>
                      <input required type="time" name="nikahtime" placeholder="Your First Name">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 2px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Is the Nikah to be performed at the Masjid or residential address?</p><br>                    
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                        <input type="radio" id="male" name="madd" value="masjid" required>
                      <label for="male" style="margin: 0 6px;">Masjid Address</label><br>
                      <input type="radio" id="no" name="madd" value="residential">
                      <label for="no" style="margin: 0 6px;">Residential Address</label><br>
                      </div>
                    <div class="col-md-12">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fname" placeholder="Your Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="address" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="relation" placeholder="Relationship to Bride/Bridegroom">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" type="text" name="email" placeholder="Your Email Id">
                    </div>
                  </div>
                  <h3>Bridegroom Details</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="namebr" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snamebr" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="date"  max="<?= date('Y-m-d') ?>"  name="bodatebr" placeholder="Your Date of Birth">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="fanamebr" placeholder="Your Father’s name">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" pattern=".{5,}"  name="phonebr" placeholder="Your Phone number">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="nationalitybr" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressbr" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                    <!-- wife data -->
                    <h3 style="margin-top: 15px;">Bride Details</h3>
                    <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="nameb" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snameb" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="date"  max="<?= date('Y-m-d') ?>"  name="bodateb" placeholder="Your Date of Birth">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="fanameb" placeholder="Your Father’s name">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" pattern=".{5,}" name="phoneb" placeholder="Your Phone number">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" pattern="[a-zA-Z ]+" name="nationalityb" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressbrq" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Supporting Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Proof of address for Bride</p>
                      <input required type="file" name="profaddbri" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Proof of address for Bridegroom</p>
                      <input required type="file" name="profaddbgrom" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Photo ID for Bride</p>
                      <input required type="file" name="brideid" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Photo ID for Bridegroom</p>
                      <input required type="file" name="bridegroomid" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Passport photo page/ Driving licence</p>
                      <input required type="file" name="passphotdr" placeholder="1st Witness Name">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Other Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If married under UK law- Civil Marriage Certificate</p>
                      <input required type="file" name="meecertifi" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If previously married -Divorce Decree Absolute / Talaq confirmation</p>
                      <input required type="file" name="previosmarr" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If widowed- death certificate</p>
                      <input required type="file" name="deathcerti" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If new Muslim (revert)- Conversion certificate</p>
                      <input required type="file" name="muslimconver" placeholder="1st Witness Name">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Witness 1 Information</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wfullname1" placeholder="Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="waddress1" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Witness 2 Information</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" pattern="[a-zA-Z ]+" name="wfullname2" placeholder="Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="waddress2" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-12" style="display:none;">
                      <input required type="number" id="price" value="0"  name="price" placeholder="Enter Price">
                    </div>
                    <!--payment mode-->
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 2px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Choose your payment mode?</p><br>                    
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                        <input type="radio" id="male" name="paymode" value="Paypal" required>
                      <label for="male" style="margin: 0 6px;">Paypal</label><br>
                      <input type="radio" id="no" name="paymode" value="stripe">
                      <label for="no" style="margin: 0 6px;">Card</label><br>
                      </div>
                    <div class="col-md-12">
                      <input type="submit" value="Submit">
                    </div>
                    <!--payment mode-->
                  </div>
                  
                  
                </form>
              </div>
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.js"></script>
  <script type="text/javascript">
  $('input[type=radio][name=madd]').change(function() {
    if (this.value == 'masjid') {
        $('#price').val('100');
    }
    else if (this.value == 'residential') {
         $('#price').val('150');
    }
});
    $(function () {
        $('#registervalidation').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                profaddbri: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Proof of address for Bride'
                        }
                    }
                },
                profaddbgrom: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Proof of address for Bridegroom'
                        }
                    }
                },
                brideid: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Photo ID for Bride'
                        }
                    }
                },
                bridegroomid: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Photo ID for Bridegroom'
                        }
                    }
                },  
                passphotdr: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload Passport photo page/ Driving licence'
                        }
                    }
                },
                meecertifi: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload UK law- Civil Marriage Certificate'
                        }
                    }
                },
                previosmarr: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload married -Divorce Decree Absolute / Talaq confirmation'
                        }
                    }
                },
                deathcerti: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload widowed- death certificate'
                        }
                    }
                },
                muslimconver: {
                    validators: {
                        file: {
                            extension: 'jpg,png,jpeg',
                            maxSize: 2 * 1024 * 1024, // 5 MB
                            message: 'Please upload a .pdf or .jpg file - max. size 2MB'
                        },
                        notEmpty: {
                            message: 'Please upload new Muslim (revert)- Conversion certificate'
                        }
                    }
                },
                madd: {
                    validators: {
                        notEmpty: {
                            message: 'Please Select Above option'
                        }
                    }
                },
                              
            }
        });

    });
  </script>