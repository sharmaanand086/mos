<?php include('header.php'); ?>
    <!--Wrapper Content Start-->
    <div id="inner-banner" style="    padding: 67px;">
   
  </div>
    <div id="wrapper" class="thankclass">
      <!--Main Content Start-->
      <div class="main-content">
        <!-- Start of Thank -->
          <section class="container">
              <div class="error-page">
                <div class="holder">
                  <h2>Thank You
                  </h2>
                  <p>Thank you for your form submission, as soon as we get this we will get back to you shortly.
                  </p>
                </div>
              </div>
          </section>
        <!-- End of Thank --> 
      </div>
	</div>
    </body>
</html>
