<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Nikah Appointment Booking</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li class="active">Nikah Appointment Booking Form</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--Contact-->
    <section class="contact-section">
      <div class="container">
        <div class="contact-row">
          <div class="row">
            <div class="col-md-12 col-sm-9">
              <div class="contact-form">
                
                <form action="<?= site_url('welcome/nikahform'); ?>" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <h5 style="    margin: 0 0 7px 0;">Date of Nikah</h5>
                      <input required pattern="[a-zA-Z ]+" type="date" name="nikahdate" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <h5 style="    margin: 0 0 7px 0;">Time of Nikah</h5>
                      <input required pattern="[a-zA-Z ]+" type="time" name="nikahtime" placeholder="Your First Name">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 2px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Is the Nikah to be performed at the Masjid or residential address?</p><br>                    
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                        <input type="radio" id="male" name="madd" value="masjid">
                      <label for="male" style="margin: 0 6px;">Masjid Address</label><br>
                      <input type="radio" id="no" name="madd" value="residential">
                      <label for="no" style="margin: 0 6px;">Residential Address</label><br>
                      </div>
                    <div class="col-md-12">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fname" placeholder="Your Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="address" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="relation" placeholder="Relationship to Bride/Bridegroom">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="email" placeholder="Your Email Id">
                    </div>
                  </div>
                  <h3>Bridegroom Details</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="namebr" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snamebr" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="date" name="bodatebr" placeholder="Your Date of Birth">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="fanamebr" placeholder="Your Father’s name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phonebr" placeholder="Your Phone number">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="nationalitybr" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressbr" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                    <!-- wife data -->
                    <h3 style="margin-top: 15px;">Bride Details</h3>
                    <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="nameb" placeholder="Your First Name">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" name="snameb" type="text" placeholder="Your Surname">
                    </div>
                    <div class="col-md-6">
                      <input required type="date" name="bodateb" placeholder="Your Date of Birth">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="fanameb" placeholder="Your Father’s name">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phoneb" placeholder="Your Phone number">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="nationalityb" placeholder="Your Nationality">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressbr" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Supporting Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Proof of address for Bride</p>
                      <input required type="file" name="praddb" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Proof of address for Bridegroom</p>
                      <input required type="file" name="praddbr" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Photo ID for Bride</p>
                      <input required type="file" name="idb" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Photo ID for Bridegroom</p>
                      <input required type="file" name="idbr" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">Passport photo page/ Driving licence</p>
                      <input required type="file" name="passportp" placeholder="1st Witness Name">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Submitted Other Documents</h3>
                  <div class="row">
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If married under UK law- Civil Marriage Certificate</p>
                      <input required type="file" name="praddb" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If previously married -Divorce Decree Absolute / Talaq confirmation</p>
                      <input required type="file" name="praddbr" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If widowed- death certificate</p>
                      <input required type="file" name="idb" placeholder="1st Witness Name">
                    </div>
                    <div class="col-md-6" style="margin-bottom: 14px;">
                      <p style="margin:0;font-size: 16px;">If new Muslim (revert)- Conversion certificate</p>
                      <input required type="file" name="idbr" placeholder="1st Witness Name">
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Witness 1 Information</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" name="wfullname1" placeholder="Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="waddress1" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                  <h3 style="margin-top: 15px;">Witness 2 Information</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <input required type="text" name="wfullname2" placeholder="Full Name">
                    </div>
                    <div class="col-md-12">
                      <textarea name="waddress2" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                  </div>
                    <div class="col-md-12">
                      <input type="submit" value="Submit">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Contact--> 
  </div>
  
  <?php include('footer.php'); ?>
