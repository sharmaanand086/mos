<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>YOUTH</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>/services">SERVICES</a></li>
        <li class="active">YOUTH</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>YOUTH</a></h2>
                <p>Hounslow Jamia Mosque Youth Centre (HJM YC) was established to cater for the physical, social, educational and religious needs, especially for the youth and the children in accordance with the teachings of the Qur’an and Sunnah and hence to gain the pleasure of the Almighty Creator.
                </p><p>
Our aim is to establish regular activities and provide services that will benefit the community. By doing this as an Ummah we would also positively contribute to the larger community as a whole and hence eliminate any negative perceptions.
</p><p>

Our weekly Youth Club (for boys) runs every Friday evening and comprises of various activities. The club is free and open to all boys aged 8-17.
</p><p>
The running of the club is done on a voluntary basis. Thus, all the administration, teaching, training etc, is provided by individuals who are making a sacrifice to improve the future of the Muslim generation.
</p><p>
We want to establish a positive perception of the Muslim youth and exhibit that they are capable of constructive & effective work within the community.
</p><p><b>
We are always looking for volunteers to come forward and help us in our cause. If you would like to volunteer or have any suggestions please email us on: <a href="mailto:admin@hounslowmasjid.co.uk" style="outline:none;color: #003471;">info@hounslowmasjid.co.uk</a></b></p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
