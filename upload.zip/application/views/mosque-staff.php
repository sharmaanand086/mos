<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Mosque Staff</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>about-us">About Us</a></li>
        <li class="active">Mosque Staff</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  
  <div id="main"> 
    <!--BLOG START-->
    <section class="blog-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7"> 
            <!--EVENT POST START-->
            <div class="post-box">
              <div class="text-box">
                <h2><a>Mosque Staff</a></h2>
                <p>
                <h4 style="font-weight: 800;">Mosque Officials</h4></p><p>
Mr Raja Ghazanfar Ali - Chairman
</p><p>
Mr Mohammed Ajaib - Vice Chairman
</p><p>
Mr Mohammad Rashad - Treasurer
</p><p>
Mr Nadeem Akhtar - Trustee (Joint Treasurer)
</p><p>
Mr Shafiq Rehman - General Secretary
</p><p>
Mr Zubair Ahmed Awan - Joint Secretary
</p><p>
Mr Raja Jawaid Akhtar - Trustee
</p><p>
Mr Chaudhry Abdul Majid - Trustee
</p><p>
Mr Sajid Ali - Trustee
</p><p>
Mr Tariq Masood - Trustee
</p><p>
Mr Wahid Hussain - Trustee 
</p><p>

<h4 style="font-weight: 800;">Imams & Religious Advisors</h4></p><p>
Shaykh Ammar Siddiqui - Head Imam
</p><p>
Imam Jafar Bilal Barakati - Khateeb
</p><p>
 

<h4 style="font-weight: 800;">ASSOCIATES</h4>
</p><p>
Tayyab Nazir, Aftab Ahmed, Nadeem Ali, Asim Suleman, Nizam Uddin
</p><p>
 

<h4 style="font-weight: 800;">Sub Committees</h4></p><p>
Al-Ehsan Academy School - Mr Ajaib, Mr. Rehman, Mr. Hussain</p><p>

Canteen - Mr Ali & Mr Rashad, Mr. Rehman</p><p>

Suffah School - Mr. Rehman, Mr. Awan, Mr. RJ Akhtar, Mr. Majeed</p><p>

Maintenance - Mr. S. Ali, Mr. RJ Akhtar, Mr. Rashad</p><p>

Function - Mr. Rashad, Mr. Hussain & Mr Awan</p>
                
              </div>
            </div>
            <!--EVENT POST END--> 
           
          </div>

          <?php include('sidebar.php') ?>

        </div>
      </div>
    </section>
    <!--BLOG END--> 
  </div>
  
<?php include('footer.php'); ?>
