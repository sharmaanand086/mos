<?php include('header.php'); ?>
  
  <!--INNER BANNER-->
  <div id="inner-banner">
    <div class="container">
      <h1>Community Hall Booking</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li class="active">Community Hall Booking Form</li>
      </ol>
    </div>
  </div>
  <!--INNER BANNER-->
  <div id="main"> 
    <!--Contact-->
    <section class="contact-section">
      <div class="container">
        <div class="contact-row">
          <div class="row">
            <div class="col-md-12 col-sm-9">
              <div class="contact-form">
                
                <form action="<?= site_url('welcome/bookingform'); ?>" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="fnameh" placeholder="Your Full Name">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" pattern=".{5,}"  title="Please Enter Vaild Phone number" name="phoneh" placeholder="Your Contact">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" type="text" name="email" placeholder="Your Email ID">
                    </div>
                    <div class="col-md-12">
                      <textarea name="addressh" required cols="6" rows="6" placeholder="Your Address"></textarea>
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="onbehalf" placeholder="On behalf of">
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="objectevent" placeholder="Nature and Object of event">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" name="appadult" placeholder="Attended by approximately Adults">
                    </div>
                    <div class="col-md-6">
                      <input required type="number" name="appchildren" placeholder="Attended by approximately Children">
                    </div>
                    <div class="col-md-6">
                      <input required onfocus="(this.type='time')" name="foodserv" type="text" placeholder="What time will food be served?">
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 5px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Do you need the Imam for Dua?</p>
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <input type="radio" id="male" name="hukr" value="yes" required>
                      <label for="male" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="no" name="hukr" value="no">
                      <label for="no" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 5px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Your details may be used for future use by HJM (event notifications, Mosque updates etc.) -
do you agree to your details being used for this purpose?</p>
                    </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 20px 0;">
                      <input type="radio" id="male" name="purpose" value="yes" required>
                      <label for="male" style="margin: 0 6px;">Yes</label><br>
                      <input type="radio" id="no" name="purpose" value="no">
                      <label for="no" style="margin: 0 6px;">No</label><br>
                    </div>
                    <div class="col-md-6">
                      <input required pattern="[a-zA-Z ]+" type="text" name="placeh" placeholder="Your Place">
                    </div>
                    <div class="col-md-6">
                      <input required  type="text" onfocus="(this.type='time')" name="timeh" placeholder="Your Time">
                    </div>
                    <div class="col-md-6">
                      <input required type="text"  name="daysh" placeholder="Your Days">
                    </div>
                    <div class="col-md-6">
                      <input required type="text" min='2021-01-01' onfocus="(this.type='date')" name="datesh" placeholder="Your Dates">
                    </div>
                    <div class="col-md-6">
                      <input required  type="number" name="damount" placeholder="Your Deposit">
                    </div>
                    <div class="col-md-6">
                      <select class="give-input" name="paymode" required>
                      <option value="">Selecct Payment </option>
                      <option value="stripe">Card</option>
                      <option value="Paypal">Paypal</option>
                    </select>
                    </div>
                  </div>
                    <div class="col-md-12" style="display: inline-flex;margin: 0 0 5px 0;">
                      <p style="font-size: 17px;margin: 0 12px 0px 0px;color: #000">Hall Charges</p>
                    </div>
                    <div class="col-md-12" style="margin: 0 0 20px 0;">
                      <input type="radio" id="male122" name="bookingprice" value="150" required>
                      <label for="male122" style="margin: 0 6px;">Funeral,Khatam, Quran Khawani etc(£150 up to 3 hours)</label><br>
                      <input type="radio" id="no122" name="bookingprice" value="250">
                      <label for="no122" style="margin: 0 6px;">Marriage, Aqiqah, Birthday etc(£250 up to 3 hours)</label><br>
                      <input type="radio" id="no22" name="bookingprice" value="500">
                      <label for="no22" style="margin: 0 6px;">Marriage, Aqiqah, Birthday etc(£500 up to 3 hours/New Function Hall)</label><br>
                    </div>
                    <div class="col-md-12">
                      <input type="submit" value="Submit">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Contact--> 
  </div>
  
  <?php include('footer.php'); ?>
