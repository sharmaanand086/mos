<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : User_model (User Model)
 * User model class to get to handle user related data 
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Slider_model extends CI_Model
{
      
     
	/**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function sliderListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id,BaseTbl.status,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm,BaseTbl.userId,Role.roleId');
        $this->db->from('tbl_sliders as BaseTbl'); 
         $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');     
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.imagename  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.roleId =', 1);  
         $this->db->or_where('BaseTbl.roleId =', 2);
        $this->db->or_where('BaseTbl.roleId =', 3);     
        $query = $this->db->get();      
        return $query->num_rows();
       // $sql = $this->db->last_query();
       // echo $sql;

    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function sliderListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id,BaseTbl.status,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm,BaseTbl.userId,Role.roleId');
        $this->db->from('tbl_sliders as BaseTbl');    
         $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left'); 
        if(!empty($searchText)) {
           $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.imagename  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.roleId =', 1);
         $this->db->or_where('BaseTbl.roleId =', 2);
        $this->db->or_where('BaseTbl.roleId =', 3);
        $this->db->order_by('BaseTbl.status', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
     
       function checkslider($data){
         $this->db->where('name' ,$data['name']);
          $this->db->from('tbl_sliders');         
           $query =  $this->db->get();
           return $query->num_rows();     
           
       
   }
   function addnewslider($data){
     $this->db->insert('tbl_sliders',$data);
     $insert_id = $this->db->insert_id();
     return $insert_id;
   }

   function getusername($id){
         $this->db->where('userId' ,$id);
          $this->db->from('tbl_users');         
           $query =  $this->db->get();
            return $query->row();
   }
   
   function getImage($id){
       $this->db->select('BaseTbl.id,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm');
         $this->db->from('tbl_sliders as BaseTbl');    
        $this->db->where('id' ,$id);
        $query =  $this->db->get(); 
        $result = $query->result();        
        return $result;
   }
      
     function approveImage($sliderid, $status)
    {
        $this->db->where('id', $sliderid);
        $this->db->update('tbl_sliders', $status);
        
        return $this->db->affected_rows();
    }

     function RejectImage($sliderid, $status)
    {
        $this->db->where('id', $sliderid);
        $this->db->update('tbl_sliders', $status);
        
        return $this->db->affected_rows();
    }

    function deleteslider($sliderid, $statusdel)
    {// $sliderid=12;
        $this->db->where('id', $sliderid);
       $this->db->update('tbl_sliders', $statusdel);   
       $path =  realpath(APPPATH.'../assets/slider/images');
       if(!empty($sliderid) && isset($sliderid)){
         $this->db->select('BaseTbl.id,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm');
         $this->db->from('tbl_sliders as BaseTbl');    
        $this->db->where('id' ,$sliderid);
        $query =  $this->db->get(); 
        $result = $query->result(); 
       foreach($result as $record){
        $oldimage= $record->imagename;
        if(file_exists($path.'/'.$oldimage)){
              unlink($path.'/'.$oldimage);
            }
       }      
            
     }  
        return $this->db->affected_rows();
    }

}