<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Commonmodel extends CI_Model {

	protected $table = 'download';
	protected $newstable = 'news';
	protected $eventtable = 'events';
	protected $praytable = 'pray';

	public function get_count() {
        return $this->db->count_all($this->table);
    }

	public function getdownload($limit, $start){

		$this->db->limit($limit, $start);
		$this->db->order_by("id", "asc");
        $query = $this->db->get($this->table);
        return $query->result();

	}

	public function contactus($data)
	{
		$this->db->insert('contactus', $data);
		return 1;
	}
	public function subcc($data)
	{
		$this->db->insert('subscribe', $data);
		return 1;
	}
	public function talkdata($data){
	    $this->db->insert('imam', $data);
	}
	public function get_news(){
		$this->db->limit(3);
		 $this->db->order_by("id", "desc");
        $query = $this->db->get($this->newstable);
        return $query->result();
	}
	public function get_all_news(){
		 $this->db->order_by("id", "asc");
        $query = $this->db->get($this->newstable);
        return $query->result();
	}
	public function get_particular_news($id){
		$this->db->where('id', $id);
        $query = $this->db->get($this->newstable);
        return $query->result();
	}
	public function get_event(){
		$this->db->limit(3);
		 $this->db->order_by("id", "desc");
        $query = $this->db->get($this->eventtable);
        return $query->result();
	}
	public function get_all_event(){
		 $this->db->order_by("id", "desc");
        $query = $this->db->get($this->eventtable);
        return $query->result();
	}
	public function get_particular_events($id){
		$this->db->where('id', $id);
        $query = $this->db->get($this->eventtable);
        return $query->result();
	}
	public function get_today_pray($month,$date){
		$this->db->where('date',$date);
		$this->db->where('month',$month);
		$query = $this->db->get('pray');
		return $query->result();
	}
	public function getallmonth(){
		$this->db->distinct();
		$this->db->select('month');
		$query = $this->db->get('pray');
		return $query->result();
	}
	public function getalldata($month){
		$this->db->where('month',$month);
		$query = $this->db->get('pray');
		return $query->result();
	}
	public function donationdata($data){
		$this->db->insert('donation', $data);
		$insert_id = $this->db->insert_id();
   		return  $insert_id;
	}
	public function paydonation($a){
		$this->db->where('id',$a);
		$query = $this->db->get('donation');
		return $query->result();
	}
	public  function updatetoken($a,$trans){
		$this->db->set('oder_id', $trans);
		$this->db->set('status', 1);
		$this->db->where('id', $a);
		$this->db->update('donation');
	}
	public function get_photo_gallery($id){
		$this->db->where('cat-id',$id);
		$query = $this->db->get('photo');
		return $query->result();
	}
	public function setbookingform($data){
		$this->db->insert('booking', $data);
		$insert_id = $this->db->insert_id();
   		return  $insert_id;
	}
	public function getbookingdata($a){
		$this->db->where('id',$a);
		$query = $this->db->get('booking');
		return $query->result();
	}
	public  function updatebookingtoken($a,$trans){
		$this->db->set('tran_id', $trans);
		$this->db->set('status', 1);
		$this->db->where('id', $a);
		$this->db->update('booking');
	}
	public function setnikahform($data){
		$this->db->insert('nikah', $data);
		$insert_id = $this->db->insert_id();
   		return  $insert_id;
	}
	public function getnikahdata($a){
		$this->db->where('id',$a);
		$query = $this->db->get('nikah');
		return $query->result();
	}
	public  function updatenikahtoken($a,$trans){
		$this->db->set('tran_id', $trans);
		$this->db->set('status', 1);
		$this->db->where('id', $a);
		$this->db->update('nikah');
	}
	//de
	public function setdivorceform($data){
		$this->db->insert('divorce', $data);
		$insert_id = $this->db->insert_id();
   		return  $insert_id;
	}
	public function getdivorcedata($a){
		$this->db->where('id',$a);
		$query = $this->db->get('divorce');
		return $query->result();
	}
	public  function updatedivorcetoken($a,$trans){
		$this->db->set('tran_id', $trans);
		$this->db->set('status', 1);
		$this->db->where('id', $a);
		$this->db->update('divorce');
	}
}