<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : User_model (User Model)
 * User model class to get to handle user related data 
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class News_model extends CI_Model
{
      
     
	/**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function newsListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id,BaseTbl.status,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm,BaseTbl.userId,Role.roleId');
        $this->db->from('tbl_news as BaseTbl'); 
         $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');     
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.imagename  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.roleId =', 1);   
         $this->db->or_where('BaseTbl.roleId =', 2);
        $this->db->or_where('BaseTbl.roleId =', 3);    
        $query = $this->db->get();      
        return $query->num_rows();
       // $sql = $this->db->last_query();
       // echo $sql;

    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function newsListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id,BaseTbl.status,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm,BaseTbl.userId,Role.roleId');
        $this->db->from('tbl_news as BaseTbl');    
         $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left'); 
        if(!empty($searchText)) {
           $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.imagename  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.roleId =', 1);
         $this->db->or_where('BaseTbl.roleId =', 2);
        $this->db->or_where('BaseTbl.roleId =', 3);
        $this->db->order_by('BaseTbl.status', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
     
       function checkNews($data){
         $this->db->where('name' ,$data['name']);
          $this->db->from('tbl_news');         
           $query =  $this->db->get();
           return $query->num_rows();     
           
       
   }
   function addnewNews($data){
     $this->db->insert('tbl_news',$data);
     $insert_id = $this->db->insert_id();
     return $insert_id;
   }

   function getusername($id){
         $this->db->where('userId' ,$id);
          $this->db->from('tbl_news');         
           $query =  $this->db->get();
            return $query->row();
   }
   
   function getImage($id){
       $this->db->select('BaseTbl.id,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm');
         $this->db->from('tbl_news as BaseTbl');    
        $this->db->where('id' ,$id);
        $query =  $this->db->get(); 
        $result = $query->result();        
        return $result;
   }
      
     function approveImage($Newsid, $status)
    {
        $this->db->where('id', $Newsid);
        $this->db->update('tbl_news', $status);
        
        return $this->db->affected_rows();
    }

     function RejectImage($Newsid, $status)
    {
        $this->db->where('id', $Newsid);
        $this->db->update('tbl_news', $status);
        
        return $this->db->affected_rows();
    }

    function deleteNews($Newsid, $statusdel)
    {// $sliderid=12;
        $this->db->where('id', $Newsid);
       $this->db->update('tbl_news', $statusdel);   
       $path =  realpath(APPPATH.'../assets/news/images');
       if(!empty($sliderid) && isset($Newsid)){
         $this->db->select('BaseTbl.id,BaseTbl.name, BaseTbl.imagename,BaseTbl.createdDtm');
         $this->db->from('tbl_news as BaseTbl');    
        $this->db->where('id' ,$Newsid);
        $query =  $this->db->get(); 
        $result = $query->result(); 
       foreach($result as $record){
        $oldimage= $record->imagename;
        if(file_exists($path.'/'.$oldimage)){
              unlink($path.'/'.$oldimage);
            }
       }      
            
     }  
        return $this->db->affected_rows();
    }

}