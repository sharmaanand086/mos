<?php

include_once('Config.php');
include_once('PayPalHelper.php');

$paypalHelper = new PayPalHelper;

header('Content-Type: application/json');
echo json_encode($paypalHelper->orderGet());