<?php
$data = $_GET['data'];
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    document.onreadystatechange = function(){
        if (document.readyState === 'complete') {
            $.ajax({
                    type: 'POST',
                    url: 'getOrderDetails.php',
                    success: function (response) {
                        if (response.ack) {
                                showPaymentExecute(response.data);
                        } else {
                            alert('Something went wrong');
                        }  
                    }
            });
        }
    }
    function showPaymentExecute(result) {
         $.ajax({
                      method: "POST",
                      url: "setthankyou.php",
                      data: {data: "<?= $data ?>",orderid:result.id }
                    })
                      .done(function( msg ) {
                        if(msg == 1){
                            window.location.href="http://hashthattags.com/mos/thankyou";
                        }
                      });
    }
</script>