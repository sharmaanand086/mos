<?php
define( 'APPLICATION_LOADED', true );
session_start();
    $rootPath = "";
    include_once('Config.php');
    include_once('Sample.php');
    include_once('conn.php');
    $baseurl='http://hashthattags.com/mos/';
    $id= $_GET['id'];
    $data = $_GET['data'];
    
    if($data == 'donation'){
    $sql = "SELECT * FROM `donation` WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $price = $row['amount'];
    }
    if($data == 'nikah'){
    $sql = "SELECT * FROM `nikah` WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $price = $row['deposite'];
    }
    if($data == 'divorce'){
    $sql = "SELECT * FROM `divorce` WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $price = $row['deposite'];
    }
    if($data == 'booking'){
    $sql = "SELECT * FROM `booking` WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $price = $row['deposite'];
    }
    
?>


<html>
<head>
<meta charset="utf-8">
<title>Hounslow Jamia Masjid and Islamic Centre</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="../assets/css/style.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/responsive.css" rel="stylesheet" type="text/css">
<link href="../assets/css/color.css" rel="stylesheet" type="text/css">
<link href="../assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="../assets/css/audioplayer.css" rel="stylesheet" type="text/css">
<link href="../assets/css/prettyPhoto.css" rel="stylesheet" type="text/css">

</head>

<body>
<div id="wrapper"> 
  <!--Header-->
  <header id="header">
    <div class="container"> <a href="<?php echo $baseurl ?>" class="logo"><img class="mylogo" src="../assets/images/logo.png" alt="logo" style="width: 79%;"></a>
      <div class="header-right">
        <div class="navigation-row">
          <nav class="navbar navbar-inverse">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav" id="nav">
                <li><a href="<?php echo $baseurl ?>">Home</a></li>
                <li><a class="menuclass" href="<?php echo $baseurl ?>about-us">About Us<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo $baseurl ?>about-us/mosque-staff">MOSQUE STAFF</a>
                    </li>
                    <li><a href="<?php echo $baseurl ?>about-us/mosque-history-objectives">Mosque History & Objectives</a></li>
                  </ul>
                </li>
                <li ><a class="menuclass" href="<?= $baseurl?>services">Services<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?= $baseurl ?>services/facilities">Facilities</a></li>
                    <li><a href="<?= $baseurl ?>services/youth">Youth</a></li>
                    <li><a href="<?= $baseurl ?>services/courses-events">Courses & Events</a></li>
                    <li><a href="<?= $baseurl ?>services/funeral-services">Funeral Services</a></li>
                    <li><a href="<?= $baseurl ?>services/marriage">Marriage</a></li>
                    <li><a href="<?= $baseurl ?>ask-IMAM">Ask IMAN</a></li>
                    <li><a href="<?= $baseurl ?>services/counselling">counselling</a></li>
                    <li><a href="<?= $baseurl ?>services/interfaith">interfaith</a></li>
                    <li><a href="<?= $baseurl ?>services/sisters">Sisters</a></li>
                    <li><a href="<?= $baseurl ?>services/new-muslims">New Muslims</a></li>
                    <li><a href="<?= $baseurl ?>services/visits-tours">Visits & Tours</a></li>
                    <li><a href="<?= $baseurl ?>services/divorce-services">Divorce Services</a></li>
                    <li><a href="<?= $baseurl ?>services/covid-19-guidance-support">Covid 19 Guidance & Support</a></li>
                    <li><a href="<?= $baseurl ?>services/jummah-booking-friday-8th-january">jummah booking</a></li>
                    <li><a href="<?= $baseurl ?>services/imam-dua-before-death">Imam Dua Before Death</a></li>
                    <li><a href="<?= $baseurl ?>booking">Booking Hall</a></li>
                  </ul>
                </li>
                <li><a class="menuclass"> Education<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo $baseurl ?>education/al-ehsan-academy">Al-Ehsan Academy</a></li>
                    <li><a href="<?php echo $baseurl ?>education/suffah-primary-school">SUFFAH PRIMARY SCHOOL</a></li>
                  </ul>
                </li>
                <li><a class="menuclass">Media<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?php echo $baseurl ?>media/video-gallery">Video Gallery</a></li>
                    <li><a href="<?php echo $baseurl ?>photo/1">Photo Gallery</a></li>
                  </ul>
                </li>
                <li><a class="menuclass">Resources<i class="fa fa-caret-down reclass" aria-hidden="true"></i></a>
                  <i class="fa fa-plus extraclass" aria-hidden="true" style="font-size: 12px;padding: 0 0 0 4px;float: right;color: #fff;"></i>
                  <ul>
                    <li><a href="<?= $baseurl ?>download">Downloads</a></li>
                    <li><a href="<?php echo $baseurl ?>useful-links">USEFUL LINKS</a></li>
                  </ul>
                </li>
                <li><a href="<?php echo $baseurl ?>donation">Donation</a></li>
                <li><a href="<?php echo $baseurl ?>the-dawah-project">Dawah Project</a></li>
                <li><a href="<?php echo $baseurl ?>contact-us">Contact</a></li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!--Search Bar-->
    <div class="overlay overlay-contentscale">
      <button type="button" class="overlay-close">Close</button>
      <div class="search-inner">
        <form method="get">
          <input type="text" placeholder="Search....." required>
          <button class="submit"><i class="fa fa-search"></i></button>
        </form>
      </div>
      <!--Search Bar Inner--> 
    </div>
    <!--Search Bar--> 
  </header>
  <!--Header--> 
<div id="inner-banner" style="    padding: 67px;">
   
  </div>

<div id="main"> 
    <!--DONATION SECTION START-->
    <section class="donation-section" style="background:#00000073">
      <div class="container">
        <div id="give-form-370-wrap" class="give-form-wrap give-display-onpage">
          <h2 class="give-form-title">Pay By Paypal</h2>
          <form id="payment-form" method="post" class="give-form give-form-370 give-form-type-multi">
            <input name="give-price-id" value="0" type="hidden">
            <div id="give_purchase_form_wrap">
              <!--<fieldset id="give_checkout_user_info">-->
              <!--  <legend>Card Info</legend>-->
              <!--  <p id="give-first-name-wrap" class="form-row form-row-first form-row-responsive">-->
              <!--    <div id="card-element">-->
                    <!-- A Stripe Element will be inserted here. -->
              <!--    </div>-->
              <!--    <div id="card-errors" role="alert" style="color: red"></div>-->
              <!--  </p>-->
              <!--</fieldset>-->
              <fieldset id="give_purchase_submit">
                
                <input type="hidden" name="camera_amount" id="camera_amount" value="<?= $price; ?>">
            	<input type="hidden" name="tax_amt" id="tax_amt" value="0">
            	<input type="hidden" name="handling_fee" id="handling_fee" value="0">
            	<input type="hidden" name="insurance_fee" id="insurance_fee" value="0">
            	<input type="hidden" name="shipping_amt" id="shipping_amt" value="0">
            	<input type="hidden" name="shipping_discount" id="shipping_discount" value="0">
            	<input type="hidden" name="total_amt" id="total_amt" value="<?= $price; ?>">
            	<input type="hidden" name="currency_Code" id="currency_Code" value="USD">
                <div class="give-submit-button-wrap give-clearfix">
                    <p id="give-final-total-wrap" class="form-wrap " style="width: 100%;text-align: center"> <span class="give-donation-total-label" style="text-align: center;float: unset;">Total Payment:</span> <span class="give-final-total-amount" data-total="50">&#163;<span id="aaa"><?= $price; ?></span></span> </p>
                    <div id="paypalCheckoutContainer" style="width: 50%;margin: auto;"></div>
                  <!--<input class="give-submit give-btn" id="give-purchase-button" name="give-purchase" value="Donation Now" type="submit">-->
                  <!--<span class="give-loading-animation"></span>-->
                  </div>
              </fieldset>
            </div>
          </form>
        </div>
      </div>
    </section>
    <!--DONATION SECTION  END--> 
  </div>
<script src="https://www.paypal.com/sdk/js?client-id=sb&intent=capture&vault=false&commit=true<?php echo isset($_GET['buyer-country']) ? "&buyer-country=" . $_GET['buyer-country'] : "" ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">

    paypal.Buttons({

        // Set your environment
        env: '<?= PAYPAL_ENVIRONMENT ?>',
        submitForm: true,

        // Set style of buttons
        style: {
            layout: 'vertical',   // horizontal | vertical
            size:   'responsive',   // medium | large | responsive
            shape:  'pill',         // pill | rect
            color:  'gold',         // gold | blue | silver | black,
            fundingicons: false,    // true | false,
            tagline: false          // true | false,
        },

        // Wait for the PayPal button to be clicked
        createOrder: function() {
            let formData = new FormData();
            formData.append('item_amt', document.getElementById("camera_amount").value);
            formData.append('tax_amt', document.getElementById("tax_amt").value);
            formData.append('handling_fee', document.getElementById("handling_fee").value);
            formData.append('insurance_fee', document.getElementById("insurance_fee").value);
            formData.append('shipping_amt', document.getElementById("shipping_amt").value);
            formData.append('shipping_discount', document.getElementById("shipping_discount").value);
            formData.append('total_amt', document.getElementById("total_amt").value);
            formData.append('currency', document.getElementById("currency_Code").value);
            formData.append('return_url',  'http://hashthattags.com/mos/paypal/success.php' + '?commit=true');
            formData.append('cancel_url', 'http://hashthattags.com/mos/paypal/failed.php');

            return fetch(
                'createOrder.php',
                {
                    method: 'POST',
                    body: formData
                }
            ).then(function(response) {
                return response.json();
            }).then(function(resJson) {
                console.log('Order ID: '+ resJson.data.id);
                $.ajax({
                      method: "POST",
                      url: "setdata.php",
                      data: { id: "<?= $id ?>", data: "<?= $data ?>",orderid:resJson.data.id }
                    })
                      .done(function( msg ) {
                        console.log(msg);
                      });
                return resJson.data.id;
            });
        },

        // Wait for the payment to be authorized by the customer
        onApprove: function(data, actions) {
            return fetch(
                'getOrderDetails.php',
                {
                    method: 'GET'
                }
            ).then(function(res) {
                return res.json();
            }).then(function(res) {
                window.location.href = 'success.php?data=<?php echo $data; ?>';
            });
        }

    }).render('#paypalCheckoutContainer');

</script>
