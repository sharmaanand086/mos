<?php
include_once('conn.php');
$data = $_POST['data'];
$orderid = $_POST['orderid'];

if($data == "donation"){
    $sql = "UPDATE `donation` SET `status` = '1' WHERE `donation`.`oder_id` = '$orderid';";
    $conn->query($sql);
    echo "1";
    
}
if($data == "nikah"){
    $sql = "UPDATE `nikah` SET `status` = '1' WHERE `nikah`.`tran_id` = '$orderid';";
    $conn->query($sql);
    echo "1";
    
}
if($data == "divorce"){
    $sql = "UPDATE `divorce` SET `status` = '1' WHERE `divorce`.`tran_id` = '$orderid';";
    $conn->query($sql);
    echo "1";
    
}
if($data == "booking"){
    $sql = "UPDATE `booking` SET `status` = '1' WHERE `booking`.`tran_id` = '$orderid';";
    $conn->query($sql);
    echo "1";
    
}


?>