<?php

$servername = "165.22.210.254";
$username = "anand";
$password = "anand";
$dbname = "mos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}