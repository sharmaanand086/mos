<?php
include_once('conn.php');
$id = $_POST['id'];
$data = $_POST['data'];
$orderid = $_POST['orderid'];


if($data == "donation"){
    $sql = "UPDATE `donation` SET `oder_id` = '$orderid' WHERE `donation`.`id` = '$id';";
    $conn->query($sql);
    
}
if($data == "nikah"){
    $sql = "UPDATE `nikah` SET `tran_id` = '$orderid' WHERE `nikah`.`id` = '$id';";
    $conn->query($sql);
    
}
if($data == "divorce"){
    $sql = "UPDATE `divorce` SET `tran_id` = '$orderid' WHERE `divorce`.`id` = '$id';";
    $conn->query($sql);
    
}
if($data == "booking"){
    $sql = "UPDATE `booking` SET `tran_id` = '$orderid' WHERE `booking`.`id` = '$id';";
    $conn->query($sql);
    
}