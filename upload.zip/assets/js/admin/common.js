/**
 * @author Kishor Mali
 */


jQuery(document).ready(function(){
	
	jQuery(document).on("click", ".deleteUser", function(){
		var userId = $(this).data("userid"),
			hitURL = baseURL + "deleteUser",
			currentRow = $(this);
		
		var confirmation = confirm("Are you sure to delete this user ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { userId : userId } 
			}).done(function(data){
				console.log(data);
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("User successfully deleted"); }
				else if(data.status = false) { alert("User deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});
	
		jQuery(document).on("click", ".approveUser", function(){
		var sliderid = $(this).data("sliderid"),
			hitURL = baseURL + "slider/approveUser",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure Approve this slider ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { sliderid : sliderid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully Approve");location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});
	jQuery(document).on("click", ".rejectslider", function(){
		var sliderid = $(this).data("sliderid"),
			hitURL = baseURL + "slider/rejectslider",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure reject this slider ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { sliderid : sliderid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully rejected");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});
	jQuery(document).on("click", ".deleteslider", function(){
		var sliderid = $(this).data("sliderid"),
			hitURL = baseURL + "slider/deleteslider",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure delete this slider ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { sliderid : sliderid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully deleted");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".approvenews", function(){
		var Newsid = $(this).data("news"),
			hitURL = baseURL + "news/approveNews",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure Approve this News ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { Newsid : Newsid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully Approve");location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".rejectnews", function(){
		var Newsid = $(this).data("news"),
			hitURL = baseURL + "news/rejectNews",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure reject this news ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { Newsid : Newsid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully rejected");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".deletenews", function(){
		var Newsid = $(this).data("news"),
			hitURL = baseURL + "news/deleteNews",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure delete this news ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { Newsid : Newsid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully deleted");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});
///galart js


jQuery(document).on("click", ".approvegalary", function(){
		var galaryid = $(this).data("galary"),
			hitURL = baseURL + "galary/approveGalary",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure Approve this Galary ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { galaryid : galaryid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully Approve");location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".rejectgalary", function(){
		var galaryid = $(this).data("galary"),
			hitURL = baseURL + "galary/rejectGalary",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure reject this Galary ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { galaryid : galaryid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully rejected");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".deletegalary", function(){
		var galaryid = $(this).data("galary"),
			hitURL = baseURL + "galary/deleteGalary",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure delete this Galary ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { galaryid : galaryid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully deleted");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});


///event js


jQuery(document).on("click", ".approveEvent", function(){
		var eventid = $(this).data("event"),
			hitURL = baseURL + "event/approveEvent",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure Approve this Event ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { eventid : eventid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully Approve");location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".rejectEvent", function(){
		var eventid = $(this).data("event"),
			hitURL = baseURL + "event/rejectEvent",
			currentRow = $(this);
	  
		var confirmation = confirm("Are you sure reject this Event ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { eventid : eventid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully rejected");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

jQuery(document).on("click", ".deleteEvent", function(){
		var eventid = $(this).data("event"),
			hitURL = baseURL + "event/deleteevent",
			currentRow = $(this);
	 
		var confirmation = confirm("Are you sure delete this Event ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { eventid : eventid } 
			}).done(function(data){
				console.log(data);
				 
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("successfully deleted");   location.reload(); }
				else if(data.status = false) { alert("failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".searchList", function(){
		
	});
	
});

 